#pragma once
#include "DisplayableObject.h"
class skybox :
	public DisplayableObject
{
public:
	skybox();
	~skybox();
};

