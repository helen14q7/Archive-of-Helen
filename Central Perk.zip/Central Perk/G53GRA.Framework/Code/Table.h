#pragma once
#include "DisplayableObject.h"
#include "Input.h"
#include"Animation.h"
class Table :
	public DisplayableObject,
	public Input,
	public Animation
{
public:
public:
	bool toTexture = false;
	GLuint* texids;
	void Display();
	void setTextures(GLuint* _texids);
	Table(GLuint* _texids);
	void HandleKey(unsigned char key, int state, int x, int y);
	void Update(const double& deltaTime);
	Table();
	~Table();

private:

	float table_length = 400.f;
	float table_width = 130.f;
	float table_height = 20.f;
	float foot_height = 40.f;
	float foot_width = 10.f;
	float foot_length = 10.f;
	float foot_offset = 20.f;
	float tip_height = 2.f;
	float tip_width = 120.f;
	float tip_length = 390.f;

	float cup_height_top = 10.f;
	float cup_height_buttom = 20.f;
	float cup_rad = 10.f;
	int color = 2;

	float _runtime = 0.f;
	float _v_teapot = 0.f;
	float _r_teapot = 0.f;
	float animationTime = 3.f;
	

	bool light = true;
	GLboolean tea = false;
	GLboolean full = false;
	//GLfloat *_mat_specular, *_mat_shininess;
	GLfloat *_mat_ambient, *_mat_diffuse, *_mat_specular, *_mat_shininess;

	void draw_Table();
	void draw_feet();
	void draw_plane();
	void draw_cup();
	
};

