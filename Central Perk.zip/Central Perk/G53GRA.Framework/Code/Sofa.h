#pragma once
#include "DisplayableObject.h"
#include "Input.h"
class Sofa :
	public DisplayableObject,
	public Input
{
public:
	bool toTexture = false;
	GLuint* texids;
	void Display();
	void setTextures(GLuint* _texids);
	void HandleKey(unsigned char key, int state, int x, int y);
	Sofa(GLuint* _texids);
	Sofa();
	~Sofa();

	void set_width(float width_input) {
		width = width_input;
	}

	void set_length(float length_input) {
		length = length_input;
	}


	void set_foot_height(float foot_height_input) {
		foot_height = foot_height_input;
	}

	void set_foot_width(float foot_width_input) {
		foot_width = foot_width_input;
	}

	void set_foot_length(float foot_length_input) {
		foot_length = foot_length_input;
	}

	void set_bottom_height(float bottom_height_input) {
		bottom_height = bottom_height_input;
	}

	void set_cushion_height(float cushion_height_input) {
		cushion_height = cushion_height_input;
	}

	void set_back_width(float back_width_input) {
		back_width = back_width_input;
	}

	void set_back_height(float back_height_input) {

		back_height = back_height_input;
	}
private:
	void drawSofa();
	bool light = true;
	float width =100.f;
	float length = 400.f;
	float height;
	float foot_height=0.f;
	float foot_width = 10.f;
	float foot_length=10.f;
	float bottom_height=20.f;
	float cushion_height =50.f;
	float back_width = 20.f;
	float back_height = 120.f;
	GLfloat *_mat_ambient, *_mat_diffuse, *_mat_specular, *_mat_shininess;



	




	void draw_feet();
	void draw_bottom();
	void draw_cushion();
	void draw_handle();
	void draw_back();
	void draw_back_tip();
};

