#pragma once
#include "DisplayableObject.h"
#include "VectorMath.h"
#include"Input.h"
#include"Animation.h"
class Skybox : public DisplayableObject,
	public Input,
	public Animation
{
public:
	Skybox();
	Skybox(GLuint* _texids);
	bool toTexture = false;
	~Skybox() {};
	GLuint* texids;
	void Display();
	void setTextures(GLuint* _texids);
	float camrad = 0;
	void HandleKey(unsigned char key, int state, int x, int y);
	void Update(const double& deltaTime);
private:
	void drawSkybox();
	double left_runtime = 0;
	double right_runtime = 0;
	double offset_left = 0;
	double offset_right = 0;
	GLboolean left_door_close = true;
	GLboolean right_door_close = true;
	
};