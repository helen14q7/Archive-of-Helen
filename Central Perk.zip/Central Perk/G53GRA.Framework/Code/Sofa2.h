#pragma once
#include "DisplayableObject.h"
#include "Input.h"
class Sofa2 :
	public DisplayableObject,
	public Input
{
public:

public:
	bool toTexture = false;
	bool light = true;
	GLuint* texids;
	void Display();
	void setTextures(GLuint* _texids);
	void HandleKey(unsigned char key, int state, int x, int y);
	Sofa2(GLuint* _texids);
	Sofa2();
	~Sofa2();
private:
	void drawSofa();
	float width = 100.f;
	float length = 200.f;
	float foot_height = 20.f;
	float foot_width = 10.f;
	float foot_length = 10.f;
	float bottom_height = 20.f;
	float cushion_height = 30.f;
	float back_width = 20.f;
	float back_height = 120.f;

	void draw_feet();
	void draw_bottom();
	void draw_cushion();
	void draw_handle();
	void draw_back();
	void draw_back_tip();
};

