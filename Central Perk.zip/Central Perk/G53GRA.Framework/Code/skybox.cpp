#include "Skybox.h"
#include<iostream>
using namespace std;
Skybox::Skybox()
{
}

Skybox::Skybox(GLuint* _texids)
{
	setTextures(_texids);
}

// define display function (to be called by MyScene)
void Skybox::Display()
{
	glDisable(GL_LIGHTING);
	glPushMatrix();
	glTranslatef(0.f, 0.f, 0.f);
	camrad = 0.5f * static_cast<float>(Scene::GetWindowHeight()) / static_cast<float>(tan(M_PI / 6.0));
	glScalef(1.9f*camrad,1.7*camrad, 2.0f*camrad);
	//glTranslatef(0,-0.5f*camrad,0);
	drawSkybox();
	glPopMatrix();
	
	glEnable(GL_LIGHTING);
}



void Skybox::setTextures(GLuint* _texids)
{
	texids = _texids;
	toTexture = true;
	// Assume all loaded correctly
	for (int i = 0; i < 9; i++)             // Check if any textures failed to load (NULL)    
		if (texids[i] == NULL) toTexture = false;   // If one texture failed, do not display any
}

//Draw a skybox just like the one from lab 5
void Skybox::drawSkybox()
{
	glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glEnable(GL_TEXTURE_2D);
	
	//if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]); 


	// NEAR SIDE
	glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
//	glColor3f(1.f, 1.f, 1.f); // cyan
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(5.f, 5.f);
	glVertex3f(-1.f, 1.f, 1.f);
	if (toTexture) glTexCoord2f(0.f, 5.f);
	glVertex3f(1.f, 1.f, 1.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(1.f, 0.f, 1.f);
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(-1.f, 0.f, 1.f);
	glEnd();

	glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[1]); 
	//bottom half of  FAR SIDE
	//glColor3f(1.f, 1.f, 1.f); // cyan
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(5.f, 5.f);  // (u,v) = (1,1)
	glVertex3f(0.2f, 0.4f, -1.f);
	if (toTexture) glTexCoord2f(0.f, 5.f);  // (u,v) = (1,1)
	glVertex3f(-1.f, 0.4f, -1.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);  // (u,v) = (1,1)
	glVertex3f(-1.f, 0.f, -1.f);
	if (toTexture) glTexCoord2f(5.f, 0.f);  // (u,v) = (1,1)
	glVertex3f(0.2f, 0.f, -1.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan
	//coffee picture of  FAR SIDE
	
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[3]);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(2.f, 1.f);  // (u,v) = (1,1)
	glVertex3f(-0.15f, 0.8f, -1.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);  // (u,v) = (1,1)
	glVertex3f(-0.65f, 0.8f, -1.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);  // (u,v) = (1,1)
	glVertex3f(-0.65f, 0.5f, -1.f);
	if (toTexture) glTexCoord2f(2.f, 0.f);  // (u,v) = (1,1)
	glVertex3f(-0.15f, 0.5f, -1.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan

	
	//bottom of the top half of FAR SIDE
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[2]);
	//glColor3f(1.f, 1.f, 1.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(5.f, 1.f);  // (u,v) = (1,1)
	glVertex3f(0.2f,0.5f,-1.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);  // (u,v) = (1,1)
	glVertex3f(-1.f, 0.5f, -1.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);  // (u,v) = (1,1)
	glVertex3f(-1.f,0.4f,-1.f);
	if (toTexture) glTexCoord2f(5.f, 0.f);  // (u,v) = (1,1)
	glVertex3f(0.2f,0.4f,-1.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan
	// top of the top half of FAR SIDE
	//glColor3f(1.f, 1.f, 1.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(5.f, 1.f);  // (u,v) = (1,1)
	glVertex3f(0.2f, 1.f, -1.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);  // (u,v) = (1,1)
	glVertex3f(-1.f, 1.f, -1.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);  // (u,v) = (1,1)
	glVertex3f(-1.f, 0.8f, -1.f);
	if (toTexture) glTexCoord2f(5.f, 0.f);  // (u,v) = (1,1)
	glVertex3f(0.2f, 0.8f, -1.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan

	// left of the top half of FAR SIDE
	//glColor3f(1.f, 1.f, 1.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 2.f);  // (u,v) = (1,1)
	glVertex3f(-0.65f, 0.8f, -1.f);
	if (toTexture) glTexCoord2f(0.f, 2.f);  // (u,v) = (1,1)
	glVertex3f(-1.f, 0.8f, -1.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);  // (u,v) = (1,1)
	glVertex3f(-1.f, 0.5f, -1.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);  // (u,v) = (1,1)
	glVertex3f(-0.65f, 0.5f, -1.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan
	// right of the top half of FAR SIDE
	//glColor3f(1.f, 1.f, 1.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 2.f);  // (u,v) = (1,1)
	glVertex3f(0.2f, 0.8f, -1.f);
	if (toTexture) glTexCoord2f(0.f, 2.f);  // (u,v) = (1,1)
	glVertex3f(-0.15f, 0.8f, -1.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);  // (u,v) = (1,1)
	glVertex3f(-0.15f, 0.5f, -1.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);  // (u,v) = (1,1)
	glVertex3f(0.2f, 0.5f, -1.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan


	
	// LEFT SIDE
	//glColor3f(0.9f, 0.9f, 1.0f); // blue
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(5.f, 5.f);
	glVertex3f(-1.f, 1.f, -1.f);
	if (toTexture) glTexCoord2f(0.f, 5.f);
	glVertex3f(-1.f, 1.f, 1.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-1.f, 0.f, 1.f);
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(-1.f, 0.f, -1.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); 
	

	//Right side//lower side
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(5.f, 5.f);
	glVertex3f(1.f, 0.25f, 1.f);
	if (toTexture) glTexCoord2f(0.f, 5.f);
	glVertex3f(1.f, 0.25f, -0.45f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(1.f, 0.f, -0.45f);
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(1.f, 0.f, 1.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan

	//right_middle brick
	
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 2.f);
	glVertex3f(1.f, 1.f, -0.35f);
	if (toTexture) glTexCoord2f(0.f, 2.f);
	glVertex3f(1.f, 1.f, -0.45f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(1.f, 0.25f, -0.45f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(1.f, 0.25f, -0.35f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan



	// RIGHT SIDE upper side  left
	//glColor3f(1.0f, 0.9f, 1.0f); // magenta
	
	glColor3f(1.f, 1.f, 1.f); // 
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[6]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(1.f, 0.95f, -0.05f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(1.f, 0.95f, -0.3f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(1.f, 0.3f, -0.3f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(1.f, 0.3f, -0.05f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan


	// RIGHT SIDE upper side green frame_left
	//glColor3f(1.0f, 0.9f, 1.0f); // magenta

	glColor3f(1.f, 1.f, 1.f); // 
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[4]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 5.f);
	glVertex3f(1.f, 1.f, -0.3f);
	if (toTexture) glTexCoord2f(0.f, 5.f);
	glVertex3f(1.f, 1.f, -0.35f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(1.f, 0.25f, -0.35f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(1.f, 0.25f, -0.3f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan


	// RIGHT SIDE upper side green frame_middle
	//glColor3f(1.0f, 0.9f, 1.0f); // magenta

	glColor3f(1.f, 1.f, 1.f); // 
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[4]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 5.f);
	glVertex3f(1.f, 1.f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 5.f);
	glVertex3f(1.f, 1.f, -0.05f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(1.f, 0.25f, -0.05f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(1.f, 0.25f, 0.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan

	// RIGHT SIDE upper side green frame_low
	//glColor3f(1.0f, 0.9f, 1.0f); // magenta

	glColor3f(1.f, 1.f, 1.f); // 
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[4]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(5.f, 1.f);
	glVertex3f(1.f, 0.3f, 1.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(1.f, 0.3f, -0.35f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(1.f, 0.25f, -0.35f);
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(1.f, 0.25f, 1.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan

	//Central perk logo_window
	glColor3f(1.f, 1.f, 1.f); // 
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[8]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(1.f, 0.75f, 0.65f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(1.f, 0.75f, 0.35f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(1.f, 0.55f, 0.35f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(1.f, 0.55f, 0.65f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan




	// RIGHT SIDE upper side green frame_right
	//glColor3f(1.0f, 0.9f, 1.0f); // magenta

	glColor3f(1.f, 1.f, 1.f); // 
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[4]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 5.f);
	glVertex3f(1.f, 1.f, 1.f);
	if (toTexture) glTexCoord2f(0.f, 5.f);
	glVertex3f(1.f, 1.f, 0.95f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(1.f, 0.25f, 0.95f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(1.f, 0.25f, 1.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan

	// RIGHT SIDE upper side green frame_right_top
	//glColor3f(1.0f, 0.9f, 1.0f); // magenta

	glColor3f(1.f, 1.f, 1.f); // 
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[4]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(5.f, 1.f);
	glVertex3f(1.f, 1.f, 1.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(1.f, 1.f, -0.35f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(1.f, 0.95f, -0.35f);
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(1.f, 0.95f, 1.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan

	// RIGHT SIDE upper side  right_up
	//glColor3f(1.0f, 0.9f, 1.0f); // magenta

	glColor3f(1.f, 1.f, 1.f); // 
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[6]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(1.f, 0.95f, 0.95f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(1.f, 0.95f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(1.f, 0.75f, 0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(1.f, 0.75f, 0.95f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan

	// RIGHT SIDE upper side  right_down


	glColor3f(1.f, 1.f, 1.f); // 
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(1.f, 0.55f, 0.95f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(1.f, 0.55f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(1.f, 0.3f, 0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(1.f, 0.3f, 0.95f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan


	// RIGHT SIDE upper side  right_right

	glColor3f(1.f, 1.f, 1.f); // 
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.5f, 1.f);
	glVertex3f(1.f, 0.75f, 0.95f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(1.f, 0.75f, 0.65f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(1.f, 0.55f, 0.65f);
	if (toTexture) glTexCoord2f(0.5f, 0.f);
	glVertex3f(1.f, 0.55f, 0.95f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan

	// RIGHT SIDE upper side  right_left

	glColor3f(1.f, 1.f, 1.f); // 
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.5f, 1.f);
	glVertex3f(1.f, 0.75f, 0.35f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(1.f, 0.75f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(1.f, 0.55f, 0.f);
	if (toTexture) glTexCoord2f(0.5f, 0.f);
	glVertex3f(1.f, 0.55f, 0.35f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan













	//if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[6]);
	//coner side
	//glColor3f(1.f, 1.f, 1.f);
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.2f, 0.f, -1.f);
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(0.2f, 0.f, -5.f / 6.f);
	if (toTexture) glTexCoord2f(5.f, 5.f);
	glVertex3f(0.2f, 1.f, -5.f / 6.f);
	if (toTexture) glTexCoord2f(0.f, 5.f);
	glVertex3f(0.2f, 1.f, -1.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan



	//if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[7]);
	//coner front

	//if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(0.5f, 0.f, -5.f / 6.f);
	if (toTexture) glTexCoord2f(2.f, 2.f);
	glVertex3f(0.5f, 1.f, -5.f / 6.f);
	if (toTexture) glTexCoord2f(0.f, 2.f);
	glVertex3f(0.2f, 1.f, -5.f / 6.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.2f, 0.f, -5.f / 6.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan
	

	double left_door_length = sqrt(pow(0.25, 2) + pow((-77.f / 120.f + 5.f / 6.f), 2));
	double right_door_length = sqrt(pow(0.25, 2) + pow((-0.45f + 77.f / 120.f), 2));
	float rotate_angle = acos(0.25 / left_door_length) * 180.0 / M_PI;

	glPushMatrix();
	glDisable(GL_CULL_FACE);
	
	glTranslatef(0.5f, 0.f, -5.f / 6.f);
	/*cout << offset_left;
	cout << "\n";*/
	glRotatef(-rotate_angle-offset_left, 0.f, 1, 0.f);
	//cout << offset_left;


	//left door
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[5]);
	glBegin(GL_QUADS);

	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, 1.f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, 0.f, 0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(left_door_length, 0.f, 0.f);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(left_door_length, 1.f, 0.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); 
	glPopMatrix();




	glPushMatrix();
	glTranslatef(1.f, 0.f, -0.45f);
	glRotatef(-rotate_angle+180+offset_right, 0.f, 1, 0.f);
	//right door
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[7]);
	//glColor3f(0.f, 0.f, 1.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(right_door_length, 1.f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(right_door_length, 0.f, 0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(0.f, 0.f, 0.f);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(0.f, 1.f, 0.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan

	glPopMatrix();
	glEnable(GL_CULL_FACE);


	if (toTexture) {
		//glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);
	}

	//if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[2]); 
	// BOTTOM SIDE
	glColor3f(115.f/255.f,113.f/255.f,106.f/255.f ); // yellow

	glBegin(GL_POLYGON);
	glVertex3f(-1.f, 0.f, 1.f);
	glVertex3f(1.f, 0.f, 1.f);
	glVertex3f(1.f, 0.f, -0.45f);
	glVertex3f(0.5f, 0.f, -5.f / 6.f);
	glVertex3f(0.2f, 0.f, -5.f / 6.f);
	glVertex3f(0.2f, 0.f, -1);
	glVertex3f(-1.f, 0.f, -1.f);
	glEnd();

	//if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[3]); 
	// TOP SIDE
	glColor3f(115.f / 255.f, 113.f / 255.f, 106.f / 255.f); // yellow
	glVertex3f(1.f, 1.f, 1.f);
	glBegin(GL_POLYGON);
	glVertex3f(-1.f, 1.f, 1.f);
	glVertex3f(-1.f, 1.f, -1.f);
	glVertex3f(0.2f, 1.f, -1);
	glVertex3f(0.2f, 1.f, -5.f / 6.f);
	glVertex3f(0.5f, 1.f, -5.f / 6.f);
	glVertex3f(1.f, 1.f, -0.45f);
	glVertex3f(1.f, 1.f, 1.f);
	
	glEnd();
	
	



	
	

	if (toTexture) {
		//glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);
	}// Disable texturing until reenabled
	//glEnable(GL_LIGHTING);                      // Reenable lighting after drawing sky
}





void Skybox::Update(const double& deltaTime) {

	//update the left door
	if (left_door_close) {
		left_runtime = 0;
	}

	if (!left_door_close) {
		cout << left_runtime;
	cout << "\n";
	if (left_runtime <= 3.6) {
		left_runtime = left_runtime + deltaTime;
	}
	}

	//update the right door

	if (right_door_close) {
		right_runtime = 0;
	}

	if (!right_door_close) {
		
		if (right_runtime <= 3.6) {
			right_runtime = right_runtime + deltaTime;
		}
	}
	
	
	left_door_close ? offset_left = left_runtime = 0 : offset_left= left_runtime*20 ;
	right_door_close ? offset_right = right_runtime = 0 : offset_right = right_runtime*20;	
}

void Skybox::HandleKey(unsigned char key, int state, int x, int y) {
	if (!state) return;

	switch (key)
	{
	case 'l':
		left_door_close = !left_door_close;
		break;
	case 'r':
		right_door_close = !right_door_close;
		break;



	}

}