#pragma once
#include "DisplayableObject.h"
#include "Input.h"
#include"Animation.h"

class People :
	public DisplayableObject,
	public Input,
	public Animation
{
public:
	bool toTexture = false;
	GLuint* texids;
	void Display();
	void setTextures(GLuint* _texids);
	People(GLuint* _texids);
	void HandleKey(unsigned char key, int state, int x, int y);
	void Update(const double& deltaTime);
	
	People();
	~People();

private:

	void drawPeople();
	GLboolean light = true;
	double _runtime = 0;
	double animationTime = 1;
	double iteration = 2;
	double counter = 0;
	float move = 0.f;
	float old_move = 0.f;
	float step_length = 50.f;
	float arm_length = 20.f;
	float arm_width = 20.f;
	float arm_height = 40.f;
	float leg_height = 60.f;
	float body_height = 90.f;
	float body_width = 50.f;
	float body_lenth = 50.f;
	float left_arm_angle_1 = 0.f;
	float left_arm_angle_2 = 0.f;
	float right_arm_angle_1 = 0.f;
	float right_arm_angle_2 = 0.f;
	float left_leg_angle_1 = 0.f;
	float left_leg_angle_2 = 0.f;
	float right_leg_angle_1 = 0.f;
	float right_leg_angle_2 = 0.f;
	float ankle_radius = 10.f;
	GLfloat *_mat_ambient, *_mat_diffuse, *_mat_specular, *_mat_shininess;
	GLboolean forward = false;
	GLboolean back = false;
	GLboolean left = false;
	GLboolean right = false;
	void drawUpperbody();
	void drawLowerbody();
	void drawCube(float length, float width, float height,int tex);
};

