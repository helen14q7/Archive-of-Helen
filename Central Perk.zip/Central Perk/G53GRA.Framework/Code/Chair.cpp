#include "Chair.h"


Chair::Chair()
{
}

Chair::Chair(GLuint* _texids) {
	setTextures(_texids);
	// Define the ambient material colour property K_a
	static GLfloat mat_ambient[] = { 0.3f, 0.3f, 0.3f, 1.f };
	// Define the diffuse material colour property K_d
	static GLfloat mat_diffuse[] = { 0.8f, 0.8f, 0.8f, 1.f };
	// Define the specular material colour property K_s
	static GLfloat mat_specular[] = { 1.f, 1.f, 1.f, 1.f };
	// Define the shininess/specular exponent factor n ( capped between 0.0 and 128.0 )
	static GLfloat mat_shininess[] = { 100.0 };

	_mat_ambient = mat_ambient;
	_mat_diffuse = mat_diffuse;
	_mat_specular = mat_specular;
	_mat_shininess = mat_shininess;
}

Chair::~Chair()
{
}

void Chair::Display() {
	//glColor3f(1.f, 1.f, 1.f);

	//glDisable(GL_LIGHTING);
	glPushMatrix();
	glTranslatef(pos[0], pos[1], pos[2]);
	glRotated(rotation[0], 1, 0, 0);
	glRotated(rotation[1], 0, 1, 0);
	glRotated(rotation[2], 0, 0, 1);

	if (light) {
		glEnable(GL_LIGHTING);
	}
	else {
		glDisable(GL_LIGHTING);
	}
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glEnable(GL_NORMALIZE);
	/////////////////////////////////////////////////

	glMaterialfv(GL_FRONT, GL_AMBIENT, _mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, _mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, _mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, _mat_shininess);
	drawChair();
	glPopAttrib();
	glPopMatrix();
	//glEnable(GL_LIGHTING);
}



void Chair::setTextures(GLuint* _texids) {
	texids = _texids;
	toTexture = true;
	// Assume all loaded correctly
	for (int i = 0; i < 1; i++)             // Check if any textures failed to load (NULL)    
		if (texids[i] == NULL) toTexture = false;   // If one texture failed, do not display any
}

void Chair::drawChair() {

	glDisable(GL_CULL_FACE);
	if (toTexture) glEnable(GL_TEXTURE_2D);
	//left_fornt_foot
	glPushMatrix();
	glTranslatef(-length / 2.f, 0.f, width / 2.f - foot_width);
	draw_feet();
	glPopMatrix();

	//right_front_foot
	glPushMatrix();
	glTranslatef((length / 2.f - foot_length), 0.f, (width / 2.f - foot_width));
	draw_feet();
	glPopMatrix();

	//left_back_foot
	glPushMatrix();
	glTranslatef(-length / 2.f, 0.f, -width / 2.f);
	draw_feet();
	glPopMatrix();

	//right_back_foot
	glPushMatrix();
	glTranslatef((length / 2.f - foot_length), 0.f, -width / 2.f);
	draw_feet();
	glPopMatrix();
	//
	//bottom
	glPushMatrix();
	glTranslatef(0.f, foot_height, 0.f);
	draw_buttom();
	glPopMatrix();

	
	
	//back
	glPushMatrix();
	glTranslatef(-length / 2.f, foot_height  + bottom_height, -width / 2.f);
	draw_back();
	glPopMatrix();

	




	if (toTexture) {
		//glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);
	}
	glEnable(GL_CULL_FACE);
}

void Chair::draw_feet() {
	glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glEnable(GL_TEXTURE_2D);

	//foot_near
	glNormal3f(0,0,1);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(foot_length, foot_height, foot_width);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, foot_height, foot_width);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, 0.f, foot_width);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(foot_length, 0.f, foot_width);
	glEnd();

	//foot_left
	glNormal3f(-1, 0, 0);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(0.f, foot_height, foot_width);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, foot_height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, 0.f, 0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(0.f, 0.f, foot_width);
	glEnd();
	//foot_right
	glNormal3f(1.f, 0.f, 0.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(foot_length, foot_height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(foot_length, foot_height, foot_width);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(foot_length, 0.f, foot_width);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(foot_length, 0.f, 0.f);
	glEnd();

	//foot_back
	glNormal3f(0.f, 0.f, -1.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(foot_length, foot_height, 0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(foot_length, 0.f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, 0.f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, foot_height, 0.f);

	glEnd();

}

void Chair::draw_buttom() {

	//bottom front
	glNormal3f(0.f, 0.f, 1.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(2.f, 2.f);
	glVertex3f(length / 2.f, 0, width / 2.f);
	if (toTexture) glTexCoord2f(2.f, 0.f);
	glVertex3f(length / 2.f, bottom_height, width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-length / 2.f, bottom_height, width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 2.f);
	glVertex3f(-length / 2.f, 0, width / 2.f);
	glEnd();

	//bottom back
	glNormal3f(0.f, 0.f, -1.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(2.f, 0.f);
	glVertex3f(length / 2.f, bottom_height, -width / 2.f);
	if (toTexture) glTexCoord2f(2.f, 2.f);
	glVertex3f(length / 2.f, 0, -width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 2.f);
	glVertex3f(-length / 2.f, 0, -width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-length / 2.f, bottom_height, -width / 2.f);
	glEnd();

	//bottom left
	glNormal3f(-1.f, 0.f, 0.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-length / 2.f, bottom_height, -width / 2.f);
	if (toTexture) glTexCoord2f(2.f, 2.f);
	glVertex3f(-length / 2.f, bottom_height, width / 2.f);
	if (toTexture) glTexCoord2f(2.f, 0.f);
	glVertex3f(-length / 2.f, 0, width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 2.f);
	glVertex3f(-length / 2.f, 0, -width / 2.f);
	glEnd();

	//bottom right
	glNormal3f(1.f, 0.f, 0.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(length / 2.f, bottom_height, -width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 2.f);
	glVertex3f(length / 2.f, 0, -width / 2.f);
	if (toTexture) glTexCoord2f(2.f, 0.f);
	glVertex3f(length / 2.f, 0, width / 2.f);
	if (toTexture) glTexCoord2f(2.f, 2.f);
	glVertex3f(length / 2.f, bottom_height, width / 2.f);
	glEnd();

	//bottom_bottom
	glNormal3f(0.f, -1.f, 0.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(length / 2.f, 0.f, -width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-length / 2.f, 0.f, -width / 2.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(-length / 2.f, 0.f, width / 2.f);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(length / 2.f, 0.f, width / 2.f);
	glEnd();

	//bottom_top
	glNormal3f(0.f, 1.f, 0.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(length / 2.f, bottom_height, -width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-length / 2.f, bottom_height, -width / 2.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(-length / 2.f, bottom_height, width / 2.f);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(length / 2.f, bottom_height, width / 2.f);
	glEnd();


}


void Chair::draw_back() {
	float offset = 0.f;
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	//front
	glNormal3f(0.f, 0.f, 1.f);
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(length, 0, back_width);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(length + offset, back_height, back_width);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-offset, back_height, back_width);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-offset, 0.f, back_width);
	glEnd();

	
	//top
	glNormal3f(0.f, 1.f, 0.f);
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(length+offset, back_height, back_width);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(length + offset, back_height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-offset, back_height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-offset, 0.f, back_width);
	glEnd();

	//back
	glNormal3f(0.f, 0.f, -1.f);
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(length, 0, 0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(length + offset, back_height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-offset, back_height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-offset, 0.f, 0.f);
	glEnd();

	//left
	glNormal3f(-1.f, 0.f, 0.f);
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(-offset, back_height, back_width);
		if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(-offset, back_height, 0.f);
		if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-offset, 0.f, 0.f);
		if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-offset, 0.f, back_width);
	glEnd();

	//right
	glNormal3f(1.f, 0.f, 0.f);
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(offset + length, back_height, back_width);
		if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(offset + length, back_height, 0.f);
		if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(length, 0.f, 0.f);
		if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(length, 0.f, back_width);
	glEnd();

}

void Chair::HandleKey(unsigned char key, int state, int x, int y) {

	if (!state) return;
	switch (key)
	{
	case 'e':
		light = !light;
		break;

	}
}