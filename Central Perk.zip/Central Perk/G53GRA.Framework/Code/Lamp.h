#pragma once
#include "DisplayableObject.h"
#include "Input.h"
class Lamp :
	public DisplayableObject,
	public Input
{
public:
	bool toTexture = false;
	GLuint* texids;
	void Display();
	void HandleKey(unsigned char key, int state, int x, int y);
	void setTextures(GLuint* _texids);
	Lamp(GLuint* _texids);
	Lamp();
	~Lamp();
private:
	bool light = true;
	float tube_length = 150.f;
	float tube_radius = 5.f;
	float buttom_height = 50.f;
	float buttom_radius = 40.f;
	GLfloat *_mat_ambient, *_mat_diffuse, *_mat_specular, *_mat_shininess;

	void drawLamp();
	void draw_tube();
	void draw_buttom();

};

