#include "Sofa.h"
#include<iostream>
#include "VectorMath.h"
using namespace std;

Sofa::Sofa()
{
}

Sofa::Sofa(GLuint* _texids) {
	setTextures(_texids);
	// Define the ambient material colour property K_a
	static GLfloat mat_ambient[] = { 0.3f, 0.3f, 0.3f, 1.f };
	// Define the diffuse material colour property K_d
	static GLfloat mat_diffuse[] = { 0.8f, 0.8f, 0.8f, 1.f };
	// Define the specular material colour property K_s
	static GLfloat mat_specular[] = { 1.f, 1.f, 1.f, 1.f };
	// Define the shininess/specular exponent factor n ( capped between 0.0 and 128.0 )
	static GLfloat mat_shininess[] = { 100.0 };

	_mat_ambient = mat_ambient;
	_mat_diffuse = mat_diffuse;
	_mat_specular = mat_specular;
	_mat_shininess = mat_shininess;

}



void Sofa::Display() {
	
	glPushMatrix();
	glTranslatef(pos[0], pos[1], pos[2]);
	glRotated(rotation[0], 1, 0, 0);
	glRotated(rotation[1], 0, 1, 0);
	glRotated(rotation[2], 0, 0, 1);
	if (light) {
			glEnable(GL_LIGHTING);
		}
		else {
			glDisable(GL_LIGHTING);
		}

	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glEnable(GL_NORMALIZE);
	//glDisable(GL_COLOR_MATERIAL);
	//glEnable(GL_COLOR_MATERIAL);
	//glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	//glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	glMaterialfv(GL_FRONT, GL_AMBIENT, _mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, _mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, _mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, _mat_shininess);
	drawSofa();
	glPopAttrib();
	glPopMatrix();
	
}

Sofa::~Sofa()
{
}

void Sofa::setTextures(GLuint* _texids) {
	texids = _texids;
	toTexture = true;
	// Assume all loaded correctly
	for (int i = 0; i < 2; i++)             // Check if any textures failed to load (NULL)    
		if (texids[i] == NULL) toTexture = false;   // If one texture failed, do not display any
}

void Sofa::drawSofa() {
	
	glDisable(GL_CULL_FACE);
	if (toTexture) glEnable(GL_TEXTURE_2D);

	//bottom
	glPushMatrix();
	glTranslatef( 0.f,0.f+foot_height,0.f);
	draw_bottom();
	glPopMatrix();

	//cushion
	glPushMatrix();
	glTranslatef(0.f, bottom_height+foot_height, 0.f);
	draw_cushion();
	glPopMatrix();

	//handle_right
	glPushMatrix();
	glTranslatef(length / 2.f, (bottom_height + cushion_height+foot_height) + (length / 12.f), -width / 2.f+back_width);
	glRotatef(90.f, 1.f, 0.f, 0.f);
	draw_handle();
	glPopMatrix();

	//handle_left
	glPushMatrix();
	glTranslatef(-length / 2.f, (bottom_height+cushion_height+foot_height)+ (length / 12.f), -width/2.f+back_width);
	glRotatef(90.f, 1.f, 0.f, 0.f);
	draw_handle();
	glPopMatrix();

	//back
	glPushMatrix();
	glTranslatef(-length / 2.f,bottom_height + cushion_height+foot_height,-width/2.f);
	draw_back();
	glPopMatrix();

	//back_tip
	glPushMatrix();
	glTranslatef(length/2.f+10.f, bottom_height + cushion_height+back_height+foot_height, -width / 2.f+back_width/2.f);
	glRotatef(90.f, 0.f, 1.f, 0.f);
	glRotatef(-90.f, 1.f, 0.f, 0.f);
	draw_back_tip();
	glPopMatrix();

	if (foot_height != 0) {
		//left_fornt_foot
		glPushMatrix();
		glTranslatef(-length / 2.f, 0.f, width / 2.f - foot_width);
		draw_feet();
		glPopMatrix();

		//right_front_foot
		glPushMatrix();
		glTranslatef((length / 2.f - foot_length), 0.f, (width / 2.f - foot_width));
		draw_feet();
		glPopMatrix();

		//left_back_foot
		glPushMatrix();
		glTranslatef(-length / 2.f, 0.f, -width / 2.f);
		draw_feet();
		glPopMatrix();

		//right_back_foot
		glPushMatrix();
		glTranslatef((length / 2.f - foot_length), 0.f, -width / 2.f);
		draw_feet();
		glPopMatrix();
	}







	if (toTexture) {
		//glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);
	}
	glEnable(GL_CULL_FACE);

}

void Sofa::draw_feet() {
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glEnable(GL_TEXTURE_2D);

	//foot_near
	//glColor3f(1.f, 1.f, 1.f); // cyan
	glNormal3f(0.f,0.f,1.f);
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(foot_length, foot_height, foot_width);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, foot_height, foot_width);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, 0.f, foot_width);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(foot_length, 0.f, foot_width);
	glEnd();

	//foot_left
	glNormal3f(-1.f, 0.f, 0.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(0.f, foot_height, foot_width);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, foot_height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, 0.f, 0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(0.f, 0.f, foot_width);
	glEnd();
	//foot_right
	//glColor3f(1.f, 1.f, 1.f); // cyan
	glNormal3f(1.f, 0.f, 0.f);
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(foot_length, foot_height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(foot_length, foot_height, foot_width);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(foot_length, 0.f, foot_width);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(foot_length, 0.f, 0.f);
	glEnd();

	//foot_back
	glNormal3f(0.f, 0.f, -1.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(foot_length, foot_height, 0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(foot_length, 0.f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, 0.f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, foot_height, 0.f);
	
	glEnd();

}

void Sofa::draw_bottom() {

	//bottom front
	glNormal3f(0.f, 0.f, 1.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(5.f, 1.f);
	glVertex3f(length / 2.f, 0,width/2.f );
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(length / 2.f, bottom_height, width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-length / 2.f, bottom_height, width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-length / 2.f, 0, width / 2.f);
	glEnd();

	//bottom back
	glNormal3f(0.f, 0.f, -1.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(length / 2.f, bottom_height, -width / 2.f);
	if (toTexture) glTexCoord2f(5.f, 1.f);
	glVertex3f(length / 2.f, 0, -width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-length / 2.f, 0, -width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-length / 2.f, bottom_height, -width / 2.f);
	glEnd();

	//bottom left
	glNormal3f(-1.f, 0.f, 0.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-length / 2.f, bottom_height, -width / 2.f);
	if (toTexture) glTexCoord2f(5.f, 1.f);
	glVertex3f(-length / 2.f, bottom_height, width / 2.f);
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(-length / 2.f,0, width / 2.f);
	if (toTexture) glTexCoord2f(0.f,1.f);
	glVertex3f(-length / 2.f, 0, -width / 2.f);
	glEnd();

	//bottom right
	glNormal3f(1.f, 0.f, 0.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(length / 2.f, bottom_height, -width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(length / 2.f, 0, -width / 2.f);
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(length / 2.f, 0, width / 2.f);
	if (toTexture) glTexCoord2f(5.f, 1.f);
	glVertex3f(length / 2.f, bottom_height, width / 2.f);
	glEnd();

	//bottom_bottom
	glNormal3f(0.f, -1.f, 0.f);
	glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(length / 2.f, 0.f, -width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-length / 2.f, 0.f, -width / 2.f);
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(-length / 2.f, 0.f, width / 2.f);
	if (toTexture) glTexCoord2f(5.f, 1.f);
	glVertex3f(length / 2.f, 0.f, width / 2.f);
	glEnd();

}

void Sofa::draw_cushion () {
	//cushion front
	glNormal3f(0.f, 0.f, 1.f);
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[1]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(length / 2.f, 0, width / 2.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(length / 2.f, cushion_height, width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-length / 2.f, cushion_height, width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-length / 2.f, 0, width / 2.f);
	glEnd();

	//cushion back
	//glColor3f(1.f, 1.f, 1.f); // cyan
	glNormal3f(0.f, 0.f, -1.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(length / 2.f, cushion_height, -width / 2.f);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(length / 2.f, 0, -width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 2.f);
	glVertex3f(-length / 2.f, 0, -width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-length / 2.f, cushion_height, -width / 2.f);
	glEnd();

	//cushion left
	//glColor3f(1.f, 1.f, 1.f); // cyan
	glNormal3f(-1.f, 0.f, 0.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-length / 2.f, cushion_height, -width / 2.f);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(-length / 2.f, cushion_height, width / 2.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(-length / 2.f, 0, width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-length / 2.f, 0, -width / 2.f);
	glEnd();

	//cushion right
	//glColor3f(1.f, 1.f, 1.f); // cyan
	glNormal3f(1.f, 0.f, 0.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(length / 2.f, cushion_height, -width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(length / 2.f, 0, -width / 2.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(length / 2.f, 0, width / 2.f);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(length / 2.f,cushion_height, width / 2.f);
	glEnd();

	//cushion top
	glColor3f(1.f, 1.f, 1.f); // cyan
	glNormal3f(0.f, 1.f, 0.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(length / 2.f, cushion_height, -width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 5.f);
	glVertex3f(-length / 2.f, cushion_height, -width / 2.f);
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(-length / 2.f, cushion_height, width / 2.f);
	if (toTexture) glTexCoord2f(5.f, 5.f);
	glVertex3f(length / 2.f,cushion_height, width / 2.f);
	glEnd();
	
}

void Sofa::draw_handle() {
	float r = length / 12.f;
	float res = 0.1*M_PI;           // resolution (in radians: equivalent to 18 degrees)
	float x = r, z = 0.f;           // initialise x and z on right of cylinder centre
	float t = 0.f;                  // initialise angle as 0
	float h = width;
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[1]);
	do
	{
		
		glBegin(GL_QUADS);          // new QUAD
			// Create first points
		glNormal3f(x, 0.f, z);
		if (toTexture) glTexCoord2f(1.f, 1.f);
		glVertex3f(x, h, z);    // top
		if (toTexture) glTexCoord2f(0.f, 1.f);
		glVertex3f(x, 0.f, z);  // bottom
		// Iterate around circle
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		// Close quad
		glNormal3f(x, 0.f, z);
		if (toTexture) glTexCoord2f(0.f, 0.f);
		glVertex3f(x, 0.f, z);  // bottom
		if (toTexture) glTexCoord2f(1.f, 0.f);
		glVertex3f(x, h, z);    // top
		glEnd();                    // end shape
	} while (t <= 2 * M_PI);        // for a full circle (360 degrees)

	
	t = 0.f;
	x = r, z = 0.f;           // initialise x and z on right of cylinder centre
	//back
	glBegin(GL_TRIANGLE_FAN);
	if (toTexture) glTexCoord2f(0.5f, 1.f);
	glVertex3f(0.f, 0.f, 0.f);
	do
	{
		 // Create first points
		glNormal3f(0.f, 1.f, 0.f);
		glNormal3f(x, 0.f, z);
		if (toTexture) glTexCoord2f(0.f, 0.f);
		glVertex3f(x, 0.f, z);  
		// Iterate around circle
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		// Close quad
		glNormal3f(x, 0.f, z);
		if (toTexture) glTexCoord2f(1.f, 0.f);
		glVertex3f(x, 0.f, z);  // bottom

							// end shape
	} while (t <= 2*M_PI);        // for a full circle (360 degrees)
	glEnd();

	//front
	t = 0.f;
	x = r, z = 0.f;           // initialise x and z on right of cylinder centre

	glBegin(GL_TRIANGLE_FAN);
	if (toTexture) glTexCoord2f(0.5f, 1.f);
	glVertex3f(0.f, h, 0.f);
	do
	{
		glNormal3f(0.f, -1.f, 0.f);
		glNormal3f(x, 0.f, z);
		if (toTexture) glTexCoord2f(0.f, 0.f);
		glVertex3f(x, h, z);  
		// Iterate around circle
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		// Close quad
		glNormal3f(x, 0.f, z);
		if (toTexture) glTexCoord2f(1.f, 0.f);
		glVertex3f(x, h, z);  

							// end shape
	} while (t <= 2*M_PI);        // for a full circle (360 degrees)
	glEnd();	
}



void Sofa::draw_back() {
	float offset = 10.f;
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[1]);

	//front
	glNormal3f(0.f, 0.f, 1.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(length , 0, back_width);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(length+offset, back_height, back_width);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-offset, back_height, back_width);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, 0.f, back_width);
	glEnd();

	//back
	glNormal3f(0.f, 0.f, -1.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(length, 0,0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(length + offset, back_height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-offset, back_height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, 0.f, 0.f);
	glEnd();

	//left
	glNormal3f(-1.f, 0.f, 0.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(-offset, back_height, back_width);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(-offset, back_height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, 0.f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, 0.f, back_width);
	glEnd();

	//right
	glNormal3f(1.f, 0.f, 0.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(offset +length , back_height, back_width);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(offset+length, back_height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(length, 0.f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(length, 0.f, back_width);
	glEnd();

	
	
}

void Sofa::draw_back_tip() {
	float r = back_width/2.f;
	float res = 0.1*M_PI;           // resolution (in radians: equivalent to 18 degrees)
	float x = r, z = 0.f;           // initialise x and z on right of cylinder centre
	float t = 0.f;                  // initialise angle as 0
	float h = length+20.f;

	glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[1]);
	//body
	do
	{
		glBegin(GL_QUADS);          // new QUAD
			// Create first points
		glNormal3f(x, 0.f, z);
		if (toTexture) glTexCoord2f(1.f, 1.f);
		glVertex3f(x, h, z);    // top
		if (toTexture) glTexCoord2f(0.f, 1.f);
		glVertex3f(x, 0.f, z);  // bottom
		// Iterate around circle
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		// Close quad
		glNormal3f(x, 0.f, z);
		if (toTexture) glTexCoord2f(0.f, 0.f);
		glVertex3f(x, 0.f, z);  // bottom
		if (toTexture) glTexCoord2f(1.f, 0.f);
		glVertex3f(x, h, z);    // top
		glEnd();                    // end shape
	} while (t <=  M_PI);

	
	x = r, z = 0.f;           // initialise x and z on right of cylinder centre
	t = 0.f;
	glBegin(GL_TRIANGLE_FAN);
	if (toTexture) glTexCoord2f(0.5f, 1.f);
	glVertex3f(0.f, 0.f, 0.f);
	do
	{
		// new QUAD
		 // Create first points
		glNormal3f(0.f, -1.f, 0.f);
		glNormal3f(x, 0.f, z);
 	if (toTexture) glTexCoord2f(0.f, 0.f);
		glVertex3f(x, 0.f, z);  // bottom
		// Iterate around circle
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		// Close quad
		glNormal3f(x, 0.f, z);
		if (toTexture) glTexCoord2f(1.f, 0.f);
		glVertex3f(x, 0.f, z);  // bottom

							// end shape
	} while (t <=  M_PI);        // for a full circle (360 degrees)
	glEnd();

	//head_front
//	glColor3f(0.f, 0.f, 0.f);
	t = 0.f;
	x = r, z = 0.f;           // initialise x and z on right of cylinder centre

	glBegin(GL_TRIANGLE_FAN);
	if (toTexture) glTexCoord2f(0.5f, 1.f);
	glVertex3f(0.f, h, 0.f);
	do
	{
		glNormal3f(0.f, 1.f, 0.f);
		glNormal3f(x, 0.f, z);
		if (toTexture) glTexCoord2f(0.f, 0.f);
		glVertex3f(x, h, z);  // bottom
		// Iterate around circle
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		// Close quad
		if (toTexture) glTexCoord2f(1.f, 0.f);
		glNormal3f(x, 0.f, z);
		glVertex3f(x, h, z);  // bottom

							// end shape
	} while (t <= M_PI);        // for a full circle (360 degrees)
	glEnd();
}

void Sofa::HandleKey(unsigned char key, int state, int x, int y) {

	if (!state) return;

	switch (key)
	{
	case 'e':
		light = !light;
		break;




	}
}




