#pragma once
#include "DisplayableObject.h"
#include"Input.h"
class Chair :
	public DisplayableObject,
	public Input
{
public:
	bool toTexture = false;
	GLuint* texids;
	void Display();
	void HandleKey(unsigned char key, int state, int x, int y);
	void setTextures(GLuint* _texids);
	Chair(GLuint* _texids);
	Chair();
	~Chair();

private:
	void drawChair();
	float width = 80.f;
	float length = 70.f;
	float foot_height = 80.f;
	float foot_width = 10.f;
	float foot_length = 10.f;
	float bottom_height = 10.f;
	float back_width = 10.f;
	float back_height = 110.f;

	void draw_feet();
	void draw_buttom();
	void draw_back();

	bool light = true;
	GLfloat *_mat_ambient, *_mat_diffuse, *_mat_specular, *_mat_shininess;
};

