#include "Lights.h"
#include<iostream>
#include "VectorMath.h"
using namespace std;

#define _LIGHT_0 0
#define _LIGHT_1 4
#define _LIGHT_2 8
#define _LIGHT_3 12

Lights::Lights()
{
	static GLfloat position[] =
	{
		// LIGHT 0 (directional light)
		-100.f, 600.f, 400.f, 0.0f,
		//LIGHT 1 (positional light)
		-400.f,430.f,-65.f,1.f,
		//LIGHT 2 (positional light)
		-250.f,430.f,-500.f,1.f,
		//Light3 (positional light)
		550.f, 430.f, 350.f, 1.f

	};
	_position = position;
	
	static GLfloat ambient[] =
	{
		// LIGHT 0 (dull yellow)
		0.5f, 0.5f, 0.5f, 1.0f,
		//Lighrt 1
		0.2f, 0.2f, 0.2f, 1.0f,
		//Light  2
		0.2f, 0.2f, 0.2f, 1.0f,
		//Light 3
		0.2f, 0.2f, 0.2f, 1.0f

		
	};
	_ambient = ambient;
	
	static GLfloat diffuse[] =
	{
		// LIGHT 0 (yellow)
		0.8f, 0.8f, 0.8f, 1.0f,
		// Light 1
		0.5f, 0.5f, 0.5f, 1.0f,
		//Light 2
		0.5f, 0.5f, 0.5f, 1.0f,
		//light3
		0.5f, 0.5f, 0.5f, 1.0f



	};
	_diffuse = diffuse;
	
	static GLfloat specular[] =
	{
		// LIGHT 0 (bright white)
		1.0f, 1.0f, 1.0f, 1.0f,
		//Light 1 (red)
		1.f, 1.f, 1.f, 1.0f,
		//Light 2
		1.f, 1.f, 1.f, 1.0f,
		//light 3
		1.f, 1.f, 1.f, 1.0f



	};
	_specular = specular;

	
}


Lights::~Lights()
{
}

void Lights::Display() {
	
		//glLightfv(GL_LIGHT0, GL_AMBIENT, &_ambient[_LIGHT_0]);      // set ambient parameter of light source
		//glLightfv(GL_LIGHT0, GL_DIFFUSE, &_diffuse[_LIGHT_0]);      // set diffuse parameter of light source
		//glLightfv(GL_LIGHT0, GL_SPECULAR, &_specular[_LIGHT_0]);    // set specular parameter of light source
		//glLightfv(GL_LIGHT0, GL_POSITION, &_position[_LIGHT_0]);    // set direction vector of light source
		//// Enable this lighting effects
		//glEnable(GL_LIGHTING);  // enable scene lighting (required to enable a light source)
		//light0 ? glEnable(GL_LIGHT0) : glDisable(GL_LIGHT0);

	glPushMatrix();
	//glColor4fv(&_diffuse[_LIGHT_1]);
	glDisable(GL_LIGHTING);

	light1 ? glColor3f(196 / 255.f, 123 / 255.f, 12 / 255.f) : glColor3f(0.f, 0.f, 0.f);
	glTranslatef(_position[_LIGHT_1 + 0], _position[_LIGHT_1 + 1], _position[_LIGHT_1 + 2]);
	glutSolidSphere(10.0, 10, 10);
	glEnable(GL_LIGHTING);
	glPopMatrix();

	glPushMatrix();
	//glColor4fv(&_diffuse[_LIGHT_1]);
	glDisable(GL_LIGHTING);
	light2 ? glColor3f(196 / 255.f, 123 / 255.f, 12 / 255.f) : glColor3f(0.f, 0.f, 0.f);
	glTranslatef(_position[_LIGHT_2 + 0], _position[_LIGHT_2 + 1], _position[_LIGHT_2 + 2]);
	glutSolidSphere(10.0, 10, 10);
	glEnable(GL_LIGHTING);
	glPopMatrix();
	
	glPushMatrix();
	//glColor4fv(&_diffuse[_LIGHT_1]);
	glDisable(GL_LIGHTING);
	light3 ? glColor3f(196 / 255.f, 123 / 255.f, 12 / 255.f) : glColor3f(0.f, 0.f, 0.f);
	glTranslatef(_position[_LIGHT_3 + 0], _position[_LIGHT_3 + 1], _position[_LIGHT_3 + 2]);
	glutSolidSphere(10.0, 10, 10);
	glEnable(GL_LIGHTING);
	glPopMatrix();

	glPushMatrix();
	glDisable(GL_LIGHTING);
	light0 ? glColor3f(196 / 255.f, 123 / 255.f, 12 / 255.f) : glColor3f(0.f, 0.f, 0.f);
	glTranslatef(_position[_LIGHT_0 + 0], _position[_LIGHT_0 + 1], _position[_LIGHT_0 + 2]);
	glutSolidSphere(20, 100, 100);
	glEnable(GL_LIGHTING);
	glPopMatrix();



}

void Lights::Update(const double& deltaTime) {

	//capture the time elapsed
	_runtime += deltaTime;

	//update the position of Light0/1/2
	_position[_LIGHT_0+0]= static_cast<GLfloat>(_radius0*cos(_runtime));
	_position[_LIGHT_0 + 2] = static_cast<GLfloat>(_radius0*sin(_runtime));
	

	//set the Light0
	glLightfv(GL_LIGHT0, GL_AMBIENT, &_ambient[_LIGHT_0]);      // set ambient parameter of light source
	glLightfv(GL_LIGHT0, GL_DIFFUSE, &_diffuse[_LIGHT_0]);      // set diffuse parameter of light source
	glLightfv(GL_LIGHT0, GL_SPECULAR, &_specular[_LIGHT_0]);    // set specular parameter of light source
	glLightfv(GL_LIGHT0, GL_POSITION, &_position[_LIGHT_0]);    // set direction vector of light source
	// Enable this lighting effects
	glEnable(GL_LIGHTING);  // enable scene lighting (required to enable a light source)
	light0 ? glEnable(GL_LIGHT0) : glDisable(GL_LIGHT0);







	//set the Light1
	glLightfv(GL_LIGHT1, GL_AMBIENT, &_ambient[_LIGHT_1]);      // set ambient parameter of light source
	glLightfv(GL_LIGHT1, GL_DIFFUSE, &_diffuse[_LIGHT_1]);      // set diffuse parameter of light source
	glLightfv(GL_LIGHT1, GL_SPECULAR, &_specular[_LIGHT_1]);    // set specular parameter of light source
	glLightfv(GL_LIGHT1, GL_POSITION, &_position[_LIGHT_1]);    // set direction vector of light source
	//set positional light parameters
	float direction[] = { 0.f,-1.f,0.f };
	glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, direction);
	glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 120.f);
	glLightf(GL_LIGHT1, GL_LINEAR_ATTENUATION, 0.000002f);
	// Enable this lighting effects
	glEnable(GL_LIGHTING);  // enable scene lighting (required to enable a light source)
	light1 ? glEnable(GL_LIGHT1) : glDisable(GL_LIGHT1);


	//set the Light2
	glLightfv(GL_LIGHT2, GL_AMBIENT, &_ambient[_LIGHT_2]);      // set ambient parameter of light source
	glLightfv(GL_LIGHT2, GL_DIFFUSE, &_diffuse[_LIGHT_2]);      // set diffuse parameter of light source
	glLightfv(GL_LIGHT2, GL_SPECULAR, &_specular[_LIGHT_2]);    // set specular parameter of light source
	glLightfv(GL_LIGHT2, GL_POSITION, &_position[_LIGHT_2]);    // set direction vector of light source
	//set positional light parameters
	//glLightf(GL_LIGHT2, GL_SPOT_CUTOFF, 15.f);
	glLightfv(GL_LIGHT2, GL_SPOT_DIRECTION, direction);
	glLightf(GL_LIGHT2, GL_SPOT_EXPONENT, 120.f);
	glLightf(GL_LIGHT2, GL_LINEAR_ATTENUATION, 0.000002f);
	// Enable this lighting effects
	glEnable(GL_LIGHTING);  // enable scene lighting (required to enable a light source)
	light2 ? glEnable(GL_LIGHT2) : glDisable(GL_LIGHT2);


	//set the Light3
	glLightfv(GL_LIGHT3, GL_AMBIENT, &_ambient[_LIGHT_3]);      // set ambient parameter of light source
	glLightfv(GL_LIGHT3, GL_DIFFUSE, &_diffuse[_LIGHT_3]);      // set diffuse parameter of light source
	glLightfv(GL_LIGHT3, GL_SPECULAR, &_specular[_LIGHT_3]);    // set specular parameter of light source
	glLightfv(GL_LIGHT3, GL_POSITION, &_position[_LIGHT_3]);    // set direction vector of light source
	//set positional light parameters
	//glLightf(GL_LIGHT2, GL_SPOT_CUTOFF, 15.f);
	glLightfv(GL_LIGHT3, GL_SPOT_DIRECTION, direction);
	glLightf(GL_LIGHT3, GL_SPOT_EXPONENT, 120.f);
	glLightf(GL_LIGHT3, GL_LINEAR_ATTENUATION, 0.000002f);
	// Enable this lighting effects
	glEnable(GL_LIGHTING);  // enable scene lighting (required to enable a light source)
	light3 ? glEnable(GL_LIGHT3) : glDisable(GL_LIGHT3);

	
}



void Lights::HandleKey(unsigned char key, int state, int x, int y) {
	if (!state) return;

	switch (key)
	{
	case 'n':
		light0  = !light0;
		light1  = !light1;
		light2  = !light2;
		light3 = !light3;
		break;
	case '0':
		light0 = !light0;
		break;

	case '1':
		light1 = !light1;
		break;

	case '2':
		light2 = !light2;
		break;

	case '3':
		light3 = !light3;
		break;



	}
}

