#include "MyScene.h"
#include "skybox.h"
#include "Sofa.h"
#include"Table.h"
#include"Sofa2.h"
#include"Table2.h"
#include"Chair.h"
#include"Lights.h"
#include"Lamp.h"
#include"People.h"
MyScene::MyScene(int argc, char** argv, const char *title, const int& windowWidth, const int& windowHeight)
	: Scene(argc, argv, title, windowWidth, windowHeight)
{

}

void MyScene::Initialise()
{
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
	//skybox
	GLuint* skybox_tex = new GLuint[9];
	skybox_tex[0] = Scene::GetTexture("./Textures/brick_wall.bmp");
	skybox_tex[1] = Scene::GetTexture("./Textures/wood_wall3.bmp");
	skybox_tex[2] = Scene::GetTexture("./Textures/orange_wall.bmp");
	skybox_tex[3] = Scene::GetTexture("./Textures/coffee_frame1.bmp");
	skybox_tex[4] = Scene::GetTexture("./Textures/greenframe.bmp");
	skybox_tex[5] = Scene::GetTexture("./Textures/small_left_door.bmp");
	skybox_tex[6] = Scene::GetTexture("./Textures/glass21.bmp");
	skybox_tex[7] = Scene::GetTexture("./Textures/small_right_door.bmp");
	skybox_tex[8] = Scene::GetTexture("./Textures/logo.bmp");
	Skybox* skybox = new Skybox(skybox_tex);
	AddObjectToScene(skybox);

	//Lights
	Lights* lights = new Lights();
	AddObjectToScene(lights);


	//sofa
	GLuint* sofa_tex = new GLuint[2];
	sofa_tex[0]= Scene::GetTexture("./Textures/fringe.bmp");
	sofa_tex[1] = Scene::GetTexture("./Textures/sofa_cushion.bmp");

	Sofa* sofa = new Sofa(sofa_tex);
	sofa->position(-100.f, 0.f, -120.f);
	AddObjectToScene(sofa);   


	//table
	GLuint* table_tex = new GLuint[4];
	table_tex[0]= Scene::GetTexture("./Textures/table_feet.bmp");
	table_tex[1]= Scene::GetTexture("./Textures/table_plane1.bmp");
	table_tex[2]= Scene::GetTexture("./Textures/smooth_glass.bmp");
	table_tex[3]= Scene::GetTexture("./Textures/green_cushion.bmp");
	

	Table* table = new Table(table_tex);
	table->position(-100.f, 0.f, 60.f);
	AddObjectToScene(table);
	glColor3f(1, 1, 1);


	//sofa2
	GLuint* sofa2_tex = new GLuint[2];
	sofa2_tex[0]= Scene::GetTexture("./Textures/sofa2_bottom1.bmp");
	sofa2_tex[1]= Scene::GetTexture("./Textures/sofa_green.bmp");
	
	Sofa* sofa2 = new Sofa(sofa2_tex);
	sofa2->position(200.f,0.f,90.f);
	sofa2->orientation(0.f,-90.f,0.f);
	sofa2->set_width(100.f);
	sofa2->set_length(200.f);
	sofa2->set_foot_height(20.f);
	sofa2->set_foot_width(10.f);
	sofa2->set_foot_length(10.f);
	sofa2->set_bottom_height(20.f);
	sofa2->set_cushion_height(30.f);
	sofa2->set_back_width(20.f);
	sofa2->set_back_height(120.f);

	
	AddObjectToScene(sofa2);
	

	//table2
	GLuint* table2_tex = new GLuint[2];
	table2_tex[0]= Scene::GetTexture("./Textures/wood_green.bmp");
	table2_tex[1]= Scene::GetTexture("./Textures/table_plane1.bmp");
	 
	Table2* table2 = new Table2(table2_tex);
	table2->position(-400.f,0.f,-65.f);
	AddObjectToScene(table2);


	//Chair
	GLuint* chair_tex = new GLuint[1];
	chair_tex[0]= Scene::GetTexture("./Textures/green_wood1.bmp");
	
	Chair* chair = new Chair(chair_tex);
	chair->position(-380.f,0.f,90.f);
	chair->orientation(0.f, 90.f, 0.f);
	AddObjectToScene(chair);

	//Lamp above table2
	GLuint* lamp_tex = new GLuint[1];
	lamp_tex[0] = Scene::GetTexture("./Textures/lamp_tube.bmp");

	Lamp* lamp = new Lamp(lamp_tex);
	lamp->position(-400.f,600.f,-65.f);
	lamp->orientation(0.f,0.f,180.f);
	AddObjectToScene(lamp);

	//table2 at the back
	
	Table2* table2_back = new Table2(table2_tex);
	table2_back->position(-250.f, 0.f, -500.f);
	AddObjectToScene(table2_back);

	//chair_left_back
	Chair* chair_left_back = new Chair(chair_tex);
	chair_left_back->position(-350.f,0.f,-500.f);
	chair_left_back->orientation(0.f,90.f,0.f);
	AddObjectToScene(chair_left_back);

	//chair_left_back
	Chair* chair_right_back = new Chair(chair_tex);
	chair_right_back->position(-150.f, 0.f, -500.f);
	chair_right_back->orientation(0.f, -90.f, 0.f);
	AddObjectToScene(chair_right_back);

	//lamp back
	Lamp* lamp_back = new Lamp(lamp_tex);
	lamp_back->position(-250.f, 600.f, -500.f);
	lamp_back->orientation(0.f, 0.f, 180.f);
	AddObjectToScene(lamp_back);

	//table window side
	Table2* table_window = new Table2(table2_tex);
	table_window->position(550.f,0.f,350.f);
	AddObjectToScene(table_window);

	//Chari_window_1
	Chair* chair_window_1 = new Chair(chair_tex);
	chair_window_1->position(550,0.f,250.f);
	//chair_window_1->orientation(0.f,180.f,0.f);
	AddObjectToScene(chair_window_1);

	//Chari_window_2
	Chair* chair_window_2 = new Chair(chair_tex);
	chair_window_2->position(550, 0.f, 450.f);
	chair_window_2->orientation(0.f,180.f,0.f);
	AddObjectToScene(chair_window_2);

	//lamp_window
	Lamp* lamp_window = new Lamp(lamp_tex);
	lamp_window->position(550.f, 600.f, 350.f);
	lamp_window->orientation(0.f, 0.f, 180.f);
	AddObjectToScene(lamp_window);

	//people

	GLuint* people_tex = new GLuint[2];
	people_tex[0] = Scene::GetTexture("./Textures/cloth2.bmp");
	people_tex[1] = Scene::GetTexture("./Textures/legs2.bmp");
	People* people = new People(people_tex);
	people->position(-100.f, 210.f, 300.f);
	AddObjectToScene(people);

}

void MyScene::Projection()
{
	GLdouble aspect = static_cast<GLdouble>(windowWidth) / static_cast<GLdouble>(windowHeight);
	gluPerspective(60.0, aspect, 1.0, 2000.0);

}
