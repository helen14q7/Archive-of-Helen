#include "Table2.h"
#include "VectorMath.h"
#include<iostream>
using namespace std;


Table2::Table2()
{
	
}


Table2::Table2(GLuint* _texids) {
	setTextures(_texids);
	// Define the ambient material colour property K_a
	static GLfloat mat_ambient[] = { 0.3f, 0.3f, 0.3f, 1.f };
	// Define the diffuse material colour property K_d
	static GLfloat mat_diffuse[] = { 0.8f, 0.8f, 0.8f, 1.f };
	// Define the specular material colour property K_s
	static GLfloat mat_specular[] = { 1.f, 1.f, 1.f, 1.f };
	// Define the shininess/specular exponent factor n ( capped between 0.0 and 128.0 )
	static GLfloat mat_shininess[] = { 100.0 };

	_mat_ambient = mat_ambient;
	_mat_diffuse = mat_diffuse;
	_mat_specular = mat_specular;
	_mat_shininess = mat_shininess;

}

Table2::~Table2()
{
}

void Table2::setTextures(GLuint* _texids) {
	texids = _texids;
	toTexture = true;
	// Assume all loaded correctly
	for (int i = 0; i < 2; i++)             // Check if any textures failed to load (NULL)    
		if (texids[i] == NULL) toTexture = false;   // If one texture failed, do not display any

}

void Table2::Display() {
	
	
	glPushMatrix();
	glTranslatef(pos[0], pos[1], pos[2]);
	if (light) {
		glEnable(GL_LIGHTING);
	}
	else {
		glDisable(GL_LIGHTING);
	}
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glEnable(GL_NORMALIZE);
	/*glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);*/
	glMaterialfv(GL_FRONT, GL_AMBIENT, _mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, _mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, _mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, _mat_shininess);

	drawTable();
	glPopAttrib();                          // restore style attributes
	glPopMatrix();
	
}


void Table2::drawTable() {
	glDisable(GL_CULL_FACE);
	
	if (toTexture) glEnable(GL_TEXTURE_2D);

	//cout << coor_change;
	//buttom
	glPushMatrix();
	glTranslated(0.f, coor_change, 0.f);
	draw_buttom();
	glPopMatrix();

	
	//tube
	glPushMatrix();
	glTranslated(0.f,buttom_height+coor_change,0.f);
	draw_tube();
	
	glTranslatef(0.f,tube_height+tube_change-10,0.f);
	draw_top();
	glPopMatrix();


	if (toTexture) {
		//glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);
	}
	glEnable(GL_CULL_FACE);

}






void Table2::draw_tube() {
	float r = tub_rad;
	float res = 0.1*M_PI;           // resolution (in radians: equivalent to 18 degrees)
	float x = r, z = 0.f;           // initialise x and z on right of cylinder centre
	float t = 0.f;                  // initialise angle as 0
	float h = tube_height+tube_change;
	//glColor3f(0.f, 0.f, 0.f); // cyan
	//glColor3f(40 / 255.f, 30 / 255.f, 22 / 255.f); // cyan//3, 79, 13//1,48,7

	//glColor3f(36 / 255.f, 26 / 255.f, 19 / 255.f);
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[1]);
	//body
	do
	{
		glBegin(GL_QUADS);          // new QUAD
			// Create first points

		glNormal3f(x, 0.f, z);
	//	glColor3f(36 / 255.f, 26 / 255.f, 19 / 255.f);
		if (toTexture) glTexCoord2f(1.f, 1.f);
		glVertex3f(x, h, z);    // top
		if (toTexture) glTexCoord2f(0.f, 1.f);
		glVertex3f(x, 0.f, z);  // bottom
		// Iterate around circle
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		// Close quad
		glNormal3f(x, 0.f, z);
		//glColor3f(36 / 255.f, 26 / 255.f, 19 / 255.f);
		if (toTexture) glTexCoord2f(0.f, 0.f);
		glVertex3f(x, 0.f, z);  // bottom
		if (toTexture) glTexCoord2f(1.f, 0.f);
		glVertex3f(x, h, z);    // top
		glEnd();                    // end shape
	} while (t <= 2 * M_PI);        // for a full circle (360 degrees)

}

void Table2::draw_buttom() {
	float r =buttom_rad+buttom_change;
	float res = 0.1*M_PI;           // resolution (in radians: equivalent to 18 degrees)
	float x = r, z = 0.f;           // initialise x and z on right of cylinder centre
	float t = 0.f;                  // initialise angle as 0
	float h = buttom_height;
	
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	//body
	do
	{
		glBegin(GL_QUADS);          // new QUAD
			// Create first points
		glNormal3f(x, 0.f, z);
		//glColor3f(36 / 255.f, 26 / 255.f, 19 / 255.f);
		if (toTexture) glTexCoord2f(1.f, 1.f);
		glVertex3f(x, h, z);    // top
		if (toTexture) glTexCoord2f(0.f, 1.f);
		glVertex3f(x, 0.f, z);  // bottom
		// Iterate around circle
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		// Close quad
		glNormal3f(x, 0.f, z);
		//glColor3f(36 / 255.f, 26 / 255.f, 19 / 255.f);
		if (toTexture) glTexCoord2f(0.f, 0.f);
		glVertex3f(x, 0.f, z);  // bottom
		if (toTexture) glTexCoord2f(1.f, 0.f);
		glVertex3f(x, h, z);    // top
		glEnd();                    // end shape
	} while (t <= 2 * M_PI);        // for a full circle (360 degrees)

	//head_top
	t = 0.f;
	x = r, z = 0.f;           // initialise x and z on right of cylinder centre

	glBegin(GL_TRIANGLE_FAN);
	if (toTexture) glTexCoord2f(0.5f, 1.f);
	glVertex3f(0.f, h, 0.f);
	do
	{
		glNormal3f(0.f, h, 0.f);
		glNormal3f(x, 0, z);
		//glColor3f(36 / 255.f, 26 / 255.f, 19 / 255.f);
		if (toTexture) glTexCoord2f(0.f, 0.f);
		glVertex3f(x, h, z);  // bottom
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		glNormal3f(x, 0, z);
		if (toTexture) glTexCoord2f(1.f, 0.f);
		glVertex3f(x, h, z);  // bottom

							// end shape
	} while (t <= 2 * M_PI);        // for a full circle (360 degrees)
	glEnd();





}

void Table2::draw_top() {
	float r = top_rad+top_rad_change;
	float res = 0.1*M_PI;           // resolution (in radians: equivalent to 18 degrees)
	float x = r, z = 0.f;           // initialise x and z on right of cylinder centre
	float t = 0.f;                  // initialise angle as 0
	float h = slide_length;
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	
	//draw_fan
	glBegin(GL_TRIANGLE_FAN);
	if (toTexture) glTexCoord2f(0.5f, 1.f);
	glVertex3f(0.f, 0.f, 0.f);
	do
	{
		glNormal3f(0.f, -1, 0.f);
		glNormal3f(x, 0, z);
		//glColor3f(40 / 255.f, 30 / 255.f, 22 / 255.f); // cyan//3, 79, 13//1,48,7
		if (toTexture) glTexCoord2f(0.f, 0.f);

		glVertex3f(x, h, z);  // bottom
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		glNormal3f(x, 0, z);
		if (toTexture) glTexCoord2f(1.f, 0.f);
		glVertex3f(x, h, z);  // bottom

							// end shape
	} while (t <= 2 * M_PI);        // for a full circle (360 degrees)
	glEnd();



	//draw_tube
	t = 0.f;
	x = r, z = 0.f;           // initialise x and z on right of cylinder centre
	float h2 = top_height+slide_length;
	//113, 115, 90
	//(84/ 255.f, 56/ 255.f, 25/ 255.f)
	//glColor3f(133/ 255.f, 92/ 255.f, 48/ 255.f); // cyan//3, 79, 13//1,48,7
	do
	{
		glBegin(GL_QUADS);          // new QUAD
			// Create first points
		glNormal3f(x, 0.f, z);
		//glColor3f(133 / 255.f, 92 / 255.f, 48 / 255.f); // cyan//3, 79, 13//1,48,7
		if (toTexture) glTexCoord2f(1.f, 1.f);
		glVertex3f(x, h2, z);    // top
		if (toTexture) glTexCoord2f(0.f, 1.f);
		glVertex3f(x, h, z);  // bottom
		// Iterate around circle
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		// Close quad
		glNormal3f(x, 0.f, z);
	//	glColor3f(133 / 255.f, 92 / 255.f, 48 / 255.f); // cyan//3, 79, 13//1,48,7
		if (toTexture) glTexCoord2f(0.f, 0.f);
		glVertex3f(x, h, z);  // bottom
		if (toTexture) glTexCoord2f(1.f, 0.f);
		glVertex3f(x, h2, z);    // top
		glEnd();                    // end shape
	} while (t <= 2 * M_PI);        // for a full circle (360 degrees)

	//draw_top
	t = 0.f;
	x = r, z = 0.f;           // initialise x and z on right of cylinder centre
	glBegin(GL_TRIANGLE_FAN);
	if (toTexture) glTexCoord2f(0.5f, 1.f);
	glVertex3f(0.f, h2, 0.f);
	do
	{
		glNormal3f(0.f, 1, 0.f);
		glNormal3f(x, 0, z);
		//glColor3f(133 / 255.f, 92 / 255.f, 48 / 255.f); // cyan//3, 79, 13//1,48,7
		if (toTexture) glTexCoord2f(0.f, 0.f);
		glVertex3f(x, h2, z);  // bottom
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		glNormal3f(x, 0, z);
		if (toTexture) glTexCoord2f(1.f, 0.f);

		glVertex3f(x, h2, z);  // bottom

							// end shape
	} while (t <= 2 * M_PI);        // for a full circle (360 degrees)
	glEnd();

}


void Table2::HandleKey(unsigned char key, int state, int x, int y) {

	if (!state) return;

	switch (key)
	{
	case 'e':
		light = !light;
		break;

	case 'j':
		jump = true;
		break;



		
	}
}


void Table2::Update(const double& deltaTime) {

	//cout << deltaTime;
	
	if (jump) {
		_runtime = fmod(_runtime + deltaTime, animationTime);          // update time in animation cycle

		float stage = 13.f*_runtime / animationTime;         // calculate stage (out of 13)
		
		if (stage < 1 || stage>12)
		{
			
			coor_change = 0;
			tube_change = 0;
	//		slide_change = 0;
			top_rad_change = 0;
			if (stage > 12) {
				jump = false;
				_runtime = 0;
			}
		}
		else if (stage < 2 || stage>11)
		{
			
			coor_change = 20;
			tube_change = -10;
			buttom_change = -2;
			top_rad_change = -10;
		}
		else if (stage < 3 || stage>10)
		{
			
			coor_change = 40;
			tube_change = -20;
			buttom_change = -4;
			top_rad_change = -15;
		}
		else if (stage < 4 || stage>9)
		{
			
			coor_change = 60;
			tube_change = -30;
			buttom_change = -6;
			top_rad_change = -20;
		}
		else if (stage < 5||stage>8)
		{
			
			coor_change = 80;
			tube_change = -40;
			buttom_change = -8;
			top_rad_change = -25;
		}
		else if (stage < 6||stage>7)
		{
			
			coor_change = 100;
			tube_change = -50;
			buttom_change = -10;
			top_rad_change = -30;
		}
		

		//cout << coor_change;
		cout << "\n";

	}


}