#pragma once
#include "DisplayableObject.h"
#include"Input.h"
#include"Animation.h"
class Table2 :
	public DisplayableObject,
	public Input,
	public Animation
	
{
public:
	bool toTexture = false;
	GLuint* texids;
	void Display();
	void HandleKey(unsigned char key, int state, int x, int y);
	void setTextures(GLuint* _texids);
	void Update(const double& deltaTime);
	Table2(GLuint* _texids);
	Table2();
	~Table2();


private:
	float buttom_rad = 40.f;
	float buttom_height = 7.f;
	float tube_height= 130.f;
	float tub_rad = 8.f;
	float slide_length = 25.f;
	//float slide_length = 150.f;
	float top_height = 10.f;
	float top_rad = 80.f;
	GLfloat *_mat_ambient, *_mat_diffuse, *_mat_specular, *_mat_shininess;

	
	double tube_change = 0;
	double buttom_change = 0;
	double top_rad_change = 0;
	double coor_change = 0;
	float _runtime = 0.f;
	float animationTime = 1.f;
	GLboolean jump = false;

	bool light = true;
//	GLfloat *_mat_ambient, *_mat_diffuse, *_mat_specular, *_mat_shininess;

	void draw_tube();
	void draw_buttom();
	void draw_top();
	void drawTable();

};

