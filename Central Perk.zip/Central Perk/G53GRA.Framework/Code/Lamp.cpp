#include "Lamp.h"
#include "VectorMath.h"



Lamp::Lamp()
{
}

Lamp::Lamp(GLuint* _texids) {
	setTextures(_texids);
	// Define the ambient material colour property K_a
	static GLfloat mat_ambient[] = { 0.2f, 0.2f, 0.2f, 1.f };
	// Define the diffuse material colour property K_d
	static GLfloat mat_diffuse[] = { 0.5f, 0.5f, 0.5f, 1.f };
	// Define the specular material colour property K_s
	static GLfloat mat_specular[] = { 1.f, 1.f, 1.f, 1.f };
	// Define the shininess/specular exponent factor n ( capped between 0.0 and 128.0 )
	static GLfloat mat_shininess[] = { 100.0 };

	_mat_ambient = mat_ambient;
	_mat_diffuse = mat_diffuse;
	_mat_specular = mat_specular;
	_mat_shininess = mat_shininess;
}

Lamp::~Lamp()
{
}

void Lamp::setTextures(GLuint* _texids) {
	texids = _texids;
	toTexture = true;
	// Assume all loaded correctly
	for (int i = 0; i < 1; i++)             // Check if any textures failed to load (NULL)    
		if (texids[i] == NULL) toTexture = false;   // If one texture failed, do not display any

}

void Lamp::Display() {

	glPushMatrix();
	glTranslatef(pos[0], pos[1], pos[2]);
	glRotated(rotation[0], 1, 0, 0);
	glRotated(rotation[1], 0, 1, 0);
	glRotated(rotation[2], 0, 0, 1);

	if (light) {
		glEnable(GL_LIGHTING);
	}
	else {
		glDisable(GL_LIGHTING);
	}
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glEnable(GL_NORMALIZE);
	
	glMaterialfv(GL_FRONT, GL_AMBIENT, _mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, _mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, _mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, _mat_shininess);

	drawLamp();
	glPopAttrib();
	glPopMatrix();
}

void Lamp::drawLamp() {
	glDisable(GL_CULL_FACE);
	if (toTexture) glEnable(GL_TEXTURE_2D);
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);

	//draw tube
	glPushMatrix();
	draw_tube();
	glPopMatrix();

	//draw_buttom
	glPushMatrix();
	glTranslatef(0.f,tube_length-20.f,0.f);
	draw_buttom();
	glPopMatrix();







	if (toTexture) {
		//glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);
	}
	glEnable(GL_CULL_FACE);


}



void Lamp::draw_tube() {
	float r = tube_radius;
	float res = 0.1*M_PI;           // resolution (in radians: equivalent to 18 degrees)
	float x = r, z = 0.f;           // initialise x and z on right of cylinder centre
	float t = 0.f;                  // initialise angle as 0
	float h = tube_length;

	//draw_tube
	
	do
	{
		glBegin(GL_QUADS);          // new QUAD
		glNormal3f(x, 0.f, z);

		if (toTexture) glTexCoord2f(1.f, 1.f);
		glVertex3f(x, h, z);
		if (toTexture) glTexCoord2f(0.f, 1.f);
		glVertex3f(x, 0.f, z);  // bottom
		
		// Iterate around circle
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		// Close quad
		glNormal3f(x, 0.f, z);
		//glColor3f(36 / 255.f, 26 / 255.f, 19 / 255.f);
		if (toTexture) glTexCoord2f(0.f, 0.f);
		glVertex3f(x, 0.f, z);  // bottom
		if (toTexture) glTexCoord2f(1.f, 0.f);
		glVertex3f(x, h, z);    // top
		glEnd();                    // end shape
	} while (t <= 2 * M_PI);        // for a full circle (360 degrees)



}


void Lamp::draw_buttom() {
	float r = buttom_radius;
	float res = 0.1*M_PI;           // resolution (in radians: equivalent to 18 degrees)
	float x = r, z = 0.f;           // initialise x and z on right of cylinder centre
	float t = 0.f;                  // initialise angle as 0
	float h = buttom_height;

	glBegin(GL_TRIANGLE_FAN);
	if (toTexture) glTexCoord2f(0.5f, 1.f);
	glVertex3f(0.f, 0.f, 0.f);
	do
	{
		glNormal3f(0.f, h, 0.f);
		if (toTexture) glTexCoord2f(0.f, 0.f);
		glVertex3f(x, h, z);  // bottom
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		if (toTexture) glTexCoord2f(1.f, 0.f);
		glVertex3f(x, h, z);  // bottom

							// end shape
	} while (t <= 2 * M_PI);        // for a full circle (360 degrees)
	glEnd();


}

void Lamp::HandleKey(unsigned char key, int state, int x, int y) {
	if (!state) return;
	switch (key)
	{
	case 'e':
		light = !light;
		break;

	}



}
