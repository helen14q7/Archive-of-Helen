#include "Table.h"
#include "VectorMath.h"
#include<iostream>
using namespace std;


Table::Table()
{
}

Table::Table(GLuint* _texids) {
	setTextures(_texids);

	// Define the ambient material colour property K_a
	static GLfloat mat_ambient[] = { 0.2f, 0.2f, 0.2f, 1.f };
	// Define the diffuse material colour property K_d
	static GLfloat mat_diffuse[] = { 0.5f, 0.5f, 0.5f, 1.f };
	// Define the specular material colour property K_s
	static GLfloat mat_specular[] = { 1.f, 1.f, 1.f, 1.f };
	// Define the shininess/specular exponent factor n ( capped between 0.0 and 128.0 )
	static GLfloat mat_shininess[] = { 100.0 };

	_mat_ambient = mat_ambient;
	_mat_diffuse = mat_diffuse;
	_mat_specular = mat_specular;
	_mat_shininess = mat_shininess;
	
	
}

Table::~Table()
{
}

void Table::Display() {

	glColor3f(1.f, 1.f, 1.f);
	

	glPushMatrix();
	glTranslatef(pos[0], pos[1], pos[2]);
	if (light) {
		glEnable(GL_LIGHTING);
	}
	else {
		glDisable(GL_LIGHTING);
	}
	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glEnable(GL_NORMALIZE);
	/////////////////////////////////////////////////
	glMaterialfv(GL_FRONT, GL_AMBIENT, _mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, _mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, _mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, _mat_shininess);
	//////////////////////////////////////////////////////////////


	draw_Table();
	glPopAttrib();                          // restore style attributes

/////////////////////////////////////////////////
	glPopMatrix();
	
}


void Table::setTextures(GLuint* _texids) {
	texids = _texids;
	toTexture = true;
	// Assume all loaded correctly
	for (int i = 0; i < 4; i++)             // Check if any textures failed to load (NULL)    
		if (texids[i] == NULL) toTexture = false;   // If one texture failed, do not display any
}





void Table::draw_Table() {
	glDisable(GL_CULL_FACE);
	if (toTexture) glEnable(GL_TEXTURE_2D);

	//left front_foot
	glPushMatrix();
	glTranslatef(-table_length/2.f+foot_offset,0.f,table_width/2.f-foot_offset-foot_width);
	draw_feet();
	glPopMatrix();

	//right front_foot
	glPushMatrix();
	glTranslatef(table_length / 2.f -foot_offset-foot_length, 0.f, table_width / 2.f - foot_offset - foot_width);
	draw_feet();
	glPopMatrix();

	//left back_foot
	glPushMatrix();
	glTranslatef(-table_length / 2.f + foot_offset, 0.f, -table_width / 2.f + foot_offset);
	draw_feet();
	glPopMatrix();


	//right back_foot
	glPushMatrix();
	glTranslatef(table_length / 2.f - foot_offset - foot_length, 0.f, -table_width / 2.f +foot_offset);
	draw_feet();
	glPopMatrix();


	//plane
	glPushMatrix();
	glTranslatef(0.f, foot_height, 0.f);
	draw_plane();
	glPopMatrix();

	//cup
	glPushMatrix();
	glTranslatef(-30.f, foot_height + table_height, 10.f);
	draw_cup();
	glPopMatrix();

	//tea pot
	glPushMatrix();
	
	glTranslatef(30.f, foot_height+table_height+12+_v_teapot, 0.f);
	glRotatef(180,0,1,0);
	glRotatef(_r_teapot,0,0,1);
	glDisable(GL_TEXTURE_2D);
	glColor3f(8 / 255.f, 72 / 255.f, 89/255.f);
	glutSolidTeapot(30.0);
	glEnable(GL_TEXTURE_2D);
	glPopMatrix();

	

	

	if (toTexture) {
		//glBindTexture(GL_TEXTURE_2D, 0);
		glDisable(GL_TEXTURE_2D);
	}
	glEnable(GL_CULL_FACE);

}

void Table::draw_feet() {
	

	//foot_near
	glNormal3f(0,0,1.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[0]);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(foot_length, foot_height, foot_width);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, foot_height, foot_width);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, 0.f, foot_width);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(foot_length, 0.f, foot_width);
	glEnd();

	//foot_left
	glNormal3f(-1.f,0,0);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(0.f, foot_height, foot_width);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, foot_height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, 0.f, 0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(0.f, 0.f, foot_width);
	glEnd();
	//foot_right
	glNormal3f(1.f,0,0);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(foot_length, foot_height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(foot_length, foot_height, foot_width);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(foot_length, 0.f, foot_width);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(foot_length, 0.f, 0.f);
	glEnd();

	//foot_back
	glNormal3f(0, 0, -1.f);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(foot_length, foot_height, 0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(foot_length, 0.f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, 0.f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, foot_height, 0.f);
	glEnd();
	glColor3f(1.f, 1.f, 1.f); // cyan
}

void Table::draw_plane() {

	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[1]);
	//plane_top
	glNormal3f(0, 1, 0);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(table_length / 2.f, table_height, -table_width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-table_length / 2.f, table_height, -table_width / 2.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(-table_length / 2.f, table_height, table_width / 2.f);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(table_length / 2.f, table_height, table_width / 2.f);
	glEnd();

	//plane front
	glNormal3f(0, 0, 1);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(5.f, 1.f);
	glVertex3f(table_length / 2.f, 0.f, table_width / 2.f);
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(table_length / 2.f, table_height, table_width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-table_length / 2.f, table_height, table_width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-table_length / 2.f, 0, table_width / 2.f);
	glEnd();

	//plane back
	glNormal3f(0, 0, -1);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(table_length / 2.f, table_height, -table_width / 2.f);
	if (toTexture) glTexCoord2f(5.f, 1.f);
	glVertex3f(table_length / 2.f, 0, -table_width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-table_length / 2.f, 0, -table_width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-table_length / 2.f, table_height, -table_width / 2.f);
	glEnd();

	//plane left
	//glColor3f(1.f, 1.f, 1.f); // cyan
	glNormal3f(-1, 0, 0);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(-table_length / 2.f, table_height, -table_width / 2.f);
	if (toTexture) glTexCoord2f(5.f, 1.f);
	glVertex3f(-table_length / 2.f, table_height, table_width / 2.f);
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(-table_length / 2.f, 0, table_width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-table_length / 2.f, 0, -table_width / 2.f);
	glEnd();

	//plane right
	glNormal3f(1, 0, 0);
	//glColor3f(1.f, 1.f, 1.f); // cyan
	
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(table_length / 2.f, table_height, -table_width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(table_length / 2.f, 0, -table_width / 2.f);
	if (toTexture) glTexCoord2f(5.f, 0.f);
	glVertex3f(table_length / 2.f, 0, table_width / 2.f);
	if (toTexture) glTexCoord2f(5.f, 1.f);
	glVertex3f(table_length / 2.f, table_height, table_width / 2.f);
	glEnd();

	//plane_bottom
	//glColor3f(1.f, 1.f, 1.f); // cyan
	glNormal3f(0, -1, 0);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(table_length / 2.f, 0.f, -table_width / 2.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(-table_length / 2.f, 0.f, -table_width / 2.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(-table_length / 2.f, 0.f, table_width / 2.f);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(table_length / 2.f, 0.f, table_width / 2.f);
	glEnd();

	



}



void Table::draw_cup() {
	
	//top
	float r = cup_rad;
	float res = 0.1*M_PI;           // resolution (in radians: equivalent to 18 degrees)
	float x = r, z = 0.f;           // initialise x and z on right of cylinder centre
	float t = 0.f;                  // initialise angle as 0
	float h = cup_height_top;
	glPushMatrix();
	glTranslatef(0.f,cup_height_buttom,0.f);
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[2]);
	do
	{
		glBegin(GL_QUADS);          // new QUAD
			// Create first points

		glNormal3f(x, 0.f, z);
		if (toTexture) glTexCoord2f(t/(2*M_PI), 1.f);
		glVertex3f(x, h, z);   
		if (toTexture) glTexCoord2f(t / (2 * M_PI), 0);
		glVertex3f(x, 0.f, z);  
		// Iterate around circle
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		// Close quad
		glNormal3f(x, 0.f, z);
		if (toTexture) glTexCoord2f(t / (2 * M_PI), 0.f);
		glVertex3f(x, 0.f, z);  // bottom
		if (toTexture) glTexCoord2f(t / (2 * M_PI), 1);
		glVertex3f(x, h, z);    // top
		glEnd();                    // end shape
	} while (t <= 2 * M_PI);        // for a full circle (360 degrees)
	glPopMatrix();

	//buttom_half
	t = 0.f;
	x = r, z = 0.f;
	h = cup_height_buttom;
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[color]);
	do
	{
		glBegin(GL_QUADS);          // new QUAD
			// Create first points

		glNormal3f(x, 0.f, z);
		//	glColor3f(36 / 255.f, 26 / 255.f, 19 / 255.f);
		if (toTexture) glTexCoord2f(t / (2 * M_PI), 1.f);
		glVertex3f(x, h, z);    // top
		if (toTexture) glTexCoord2f(t / (2 * M_PI), 0.f);
		glVertex3f(x, 0.f, z);  // bottom
		// Iterate around circle
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		// Close quad
		glNormal3f(x, 0.f, z);
		//glColor3f(36 / 255.f, 26 / 255.f, 19 / 255.f);
		if (toTexture) glTexCoord2f(t / (2 * M_PI), 0.f);
		glVertex3f(x, 0.f, z);  // bottom
		if (toTexture) glTexCoord2f(t / (2 * M_PI), 1.f);
		glVertex3f(x, h, z);    // top
		glEnd();                    // end shape
	} while (t <= 2 * M_PI);        // for a full circle (360 degrees)


	//buttom_buttom
	t = 0.f;
	x = r, z = 0.f;           // initialise x and z on right of cylinder centre

	glBegin(GL_TRIANGLE_FAN);
	if (toTexture) glTexCoord2f(0.5f, 1.f);
	glVertex3f(0.f, 0, 0.f);
	do
	{
		glNormal3f(0.f, h, 0.f);
		glNormal3f(x, 0, z);
		//glColor3f(36 / 255.f, 26 / 255.f, 19 / 255.f);
		if (toTexture) glTexCoord2f(0.f, 0.f);
		glVertex3f(x, 0, z);  // bottom
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		glNormal3f(x, 0, z);
		if (toTexture) glTexCoord2f(1.f, 0.f);
		glVertex3f(x, 0, z);  // bottom

							// end shape
	} while (t <= 2 * M_PI);        // for a full circle (360 degrees)
	glEnd();

	//top

	t = 0.f;
	x = r, z = 0.f;           // initialise x and z on right of cylinder centre
	if (full) {
		glBegin(GL_TRIANGLE_FAN);
		if (toTexture) glTexCoord2f(0.5f, 1.f);
		glVertex3f(0.f, 0, 0.f);
		do
		{
			glNormal3f(0.f, h, 0.f);
			//glColor3f(36 / 255.f, 26 / 255.f, 19 / 255.f);
			glNormal3f(x, 0, z);
			if (toTexture) glTexCoord2f(0.f, 0.f);
			glVertex3f(x, h, z);  // bottom
			t += res;               // add increment to angle
			x = r * cos(t);           // move x and z around circle
			z = r * sin(t);
			glNormal3f(x, 0, z);
			if (toTexture) glTexCoord2f(1.f, 0.f);
			glVertex3f(x, h, z);  // bottom

								// end shape
		} while (t <= 2 * M_PI);        // for a full circle (360 degrees)
		glEnd();
	}
}





void Table::HandleKey(unsigned char key, int state, int x, int y) {

	if (!state) return;

	switch (key)
	{	
	case 'e':
		light = !light;
		break;
	case 't':
		tea = true;
		break;

	}
}

void Table::Update(const double& deltaTime) {

	if (tea) {
		_runtime = fmod(_runtime + deltaTime, animationTime);          // update time in animation cycle
		float stage = 28.f*_runtime / animationTime;         // calculate stage (out of 28)
		cout << stage;
		cout << "\n";
		if (stage < 1 || stage>27)
		{
			 _v_teapot = 0.f;
			 _r_teapot = 0.f;
			 color = 2;
		
			if (stage > 12) {
				tea = false;
				_runtime = 0;
			}
		}
		else if (stage < 2 || stage>26)
		{
			_v_teapot = 10.f;
			 _r_teapot = 0.f;
			
		}
		else if (stage < 3 || stage>25)
		{
			float _v_teapot = 20.f;
			float _r_teapot = 0.f;

		}
		else if (stage < 4 || stage>24)
		{
			 _v_teapot = 30.f;
			 _r_teapot = 0.f;

		}
		else if (stage < 5 || stage>23)
		{
			 _v_teapot = 40.f;
			 _r_teapot = 0.f;
			
		}
		else if (stage < 7 || stage>22)
		{
			 _v_teapot = 50.f;
			 _r_teapot = 0.f;

		}

		else if (stage < 8 || stage>21)
		{
			_v_teapot = 50.f;
			_r_teapot = -5.f;

		}
		else if (stage < 9 || stage>20)
		{
			_v_teapot = 50.f;
			_r_teapot = -10.f;

		}
		else if (stage < 10 || stage>19)
		{
			_v_teapot = 50.f;
			_r_teapot = -15.f;

		}
		else if (stage < 11|| stage>18)
		{
			_v_teapot = 50.f;
			_r_teapot = -20.f;

		}
		else if (stage < 12 || stage>17)
		{
			_v_teapot = 50.f;
			_r_teapot = -25.f;

		}
		else if (stage < 13 || stage>16)
		{
			_v_teapot = 50.f;
			_r_teapot = -30.f;

		}
		else if (stage < 14 || stage>15)
		{
			_v_teapot = 50.f;
			_r_teapot = -35.f;
			color = 3;

		}
		
		


	}

}