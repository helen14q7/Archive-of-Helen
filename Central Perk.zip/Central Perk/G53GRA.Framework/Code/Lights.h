#pragma once
#include "DisplayableObject.h"
#include "Input.h"
#include"Animation.h"
class Lights :
	public DisplayableObject,
	public Input,
	public Animation
{
public:
	Lights();
	~Lights();
	void Display();
	void HandleKey(unsigned char key, int state, int x, int y);
	void Update(const double& deltaTime);
private:
	//GLboolean _showlight0 = true;
	double _runtime = 0.0;
	double _radius0 = 450.0;
	/*double _radius1 = 100.0;
	double _radius2 = 100.0;
*/
	GLboolean light0 = true;
	GLboolean light1 = true;
	GLboolean light2 = true;
	GLboolean light3 = true;
	GLboolean _flagVisualise;
	GLfloat *_position, *_ambient, *_diffuse, *_specular;
	GLfloat *_mat_ambient, *_mat_diffuse, *_mat_specular, *_mat_shininess;

	
};

