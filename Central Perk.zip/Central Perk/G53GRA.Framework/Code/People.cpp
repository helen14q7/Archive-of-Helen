#include"People.h"
#include<iostream>
#include "VectorMath.h"
using namespace std;

People::People() {

}

People::~People() {

}

People::People(GLuint* _texids) {
	setTextures(_texids);

	// Define the ambient material colour property K_a
	static GLfloat mat_ambient[] = { 0.2f, 0.2f, 0.2f, 1.f };
	// Define the diffuse material colour property K_d
	static GLfloat mat_diffuse[] = { 0.5f, 0.5f, 0.5f, 1.f };
	// Define the specular material colour property K_s
	static GLfloat mat_specular[] = { 1.f, 1.f, 1.f, 1.f };
	// Define the shininess/specular exponent factor n ( capped between 0.0 and 128.0 )
	static GLfloat mat_shininess[] = { 100.0 };

	_mat_ambient = mat_ambient;
	_mat_diffuse = mat_diffuse;
	_mat_specular = mat_specular;
	_mat_shininess = mat_shininess;
}

void People::setTextures(GLuint* _texids) {
	texids = _texids;
	toTexture = true;
	// Assume all loaded correctly
	for (int i = 0; i < 2; i++)             // Check if any textures failed to load (NULL)    
		if (texids[i] == NULL) toTexture = false;   // If one texture failed, do not display any
}

void People::Display() {

	glPushMatrix();
	
	glTranslatef(pos[0], pos[1], pos[2]);
	glRotated(rotation[0], 1, 0, 0);
	glRotated(rotation[1], 0, 1, 0);
	glRotated(rotation[2], 0, 0, 1);
	
	if (light) {
		glEnable(GL_LIGHTING);
	}
	else {
		glDisable(GL_LIGHTING);
	}

	glPushAttrib(GL_ALL_ATTRIB_BITS);
	glEnable(GL_NORMALIZE);
	glMaterialfv(GL_FRONT, GL_AMBIENT, _mat_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, _mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, _mat_specular);
	glMaterialfv(GL_FRONT, GL_SHININESS, _mat_shininess);

	glPushMatrix();
	drawPeople();
	glPopMatrix();
	glPopAttrib();
	glPopMatrix();
}


void People::drawPeople() {

	glDisable(GL_CULL_FACE);
	
	glTranslatef(-body_lenth/2.f, 0.f, move-body_width/2.f);
	//    draw upper body
	glPushMatrix();
	//glRotated(upperAngle, 0.f, 0.f, 1.f);
	drawUpperbody();
	glPopMatrix();

	//draw lower body
	glPushMatrix();
	//   glRotated(-45.f, 0.f, 0.f, 1.f);
	drawLowerbody();
	glPopMatrix();

	glEnable(GL_CULL_FACE);


}

void People::drawUpperbody() {
	//body
	drawCube(body_lenth, body_width, body_height,0);
	
	//draw_head
	glPushMatrix();
	glTranslatef(body_lenth/2.f,35.f,body_width/2.f);
	glDisable(GL_TEXTURE_2D);

	//draw_face left eye
	glDisable(GL_LIGHTING);
	glPushMatrix();
	glTranslatef(-8, 10, 25);
	glColor3f(0.f,0.f,0.f);
	glBegin(GL_POLYGON);
	float radius = 7.f;
	double angle1 = 0.0;
	float circle_points = 100;
	float angle = 2.0f * 3.1416f / circle_points;
	glVertex2d(radius * cos(0.0), radius * sin(0.0));
	int i;
	for (i = 0; i <circle_points; i++)
	{
		glVertex2d(radius * cos(angle1), radius *sin(angle1));
		angle1 += angle;
	}
	glEnd();
	glPopMatrix();

	//right eye
	glLineWidth(2.f);
	glBegin(GL_LINES);
	glVertex3f(-8, 10, 25);
	glVertex3f(12, 10, 25);
	glEnd();
	glPushMatrix();
	glTranslatef(12, 10, 30);
	glColor3f(0.f, 0.f, 0.f);
	glBegin(GL_POLYGON);
	glVertex2d(radius * cos(0.0), radius * sin(0.0));
	for (i = 0; i < circle_points; i++)
	{
		glVertex2d(radius * cos(angle1), radius *sin(angle1));
		angle1 += angle;
	}
	glEnd();
	glPopMatrix();

	//mouth

	glPushMatrix();
	glTranslatef(2, -5, 25);
	glRotatef(90,1,0,0);
	glColor3f(0.f, 0.f, 0.f);

	float r = 10;
	float res = 0.1*M_PI;           // resolution (in radians: equivalent to 18 degrees)
	float x = r, z = 0.f;           // initialise x and z on right of cylinder centre
	float t = 0.f;                  // ini
	glLineWidth(3);


	do
	{
		glBegin(GL_LINES);
		glVertex3f(x, 0, z);  // bottom
		t += res;               // add increment to angle
		x = r * cos(t);           // move x and z around circle
		z = r * sin(t);
		glVertex3f(x, 0, z);  // bottom
		glEnd();
							// end shape
	} while (t <=  M_PI);        // for a full circle (360 degrees)
	x = r, z = 0.f;
	glBegin(GL_LINES);
	glVertex3f(-r, 0, 0);  // bottom
	glVertex3f(r, 0, z);  // bottom
	glEnd();

	glPopMatrix();


	//glEnable(GL_LIGHTING);
	if (light) {
		glEnable(GL_LIGHTING);
	}
	else {
		glDisable(GL_LIGHTING);
	}
	glColor3f(1.f, 1.f, 1.f);
	glutSolidSphere(25.f,10,10);
	glEnable(GL_TEXTURE_2D);
	glPopMatrix();

	//draw_left arm
	glPushMatrix();
	glTranslatef(-arm_length, -arm_length/2.f, body_width/4.f);
	glRotatef(left_arm_angle_1,1.f,0.f,0.f);
	drawCube(arm_length,arm_width,arm_height,1);

		glPushMatrix();
		glTranslatef(0.f,  -arm_height, 0.f);
		glRotatef(left_arm_angle_2, 1.f, 0.f, 0.f);
		drawCube(arm_length, arm_width, arm_height, 1);
		glPopMatrix();

	glPopMatrix();

	//draw_right arm
	glPushMatrix();
	glTranslatef(body_lenth,  - arm_length/2.f, body_width / 4.f);
	glRotatef(right_arm_angle_1, 1.f, 0.f, 0.f);
	drawCube(arm_length, arm_width, arm_height, 1);

	glPushMatrix();
	glTranslatef(0.f,   - arm_height, 0.f);
	glRotatef(right_arm_angle_2, 1.f, 0.f, 0.f);
	drawCube(arm_length, arm_width, arm_height, 1);
	glPopMatrix();

	glPopMatrix();



}

void People::drawLowerbody() {
	//draw left leg
	glPushMatrix();
	glTranslatef(0.f, -body_height, body_width / 4.f);
	glRotatef(left_leg_angle_1, 1.f, 0.f, 0.f);
	drawCube(arm_length, arm_width, leg_height, 1);

	glPushMatrix();
	glTranslatef(0.f, -leg_height, 0.f);
	glRotatef(left_leg_angle_2, 1.f, 0.f, 0.f);
	drawCube(arm_length, arm_width, leg_height, 1);
	glPopMatrix();

	glPopMatrix();

	//draw right leg
	glPushMatrix();
	glTranslatef(body_lenth-arm_length, -body_height, body_width / 4.f);
	glRotatef(right_leg_angle_1, 1.f, 0.f, 0.f);
	drawCube(arm_length, arm_width, leg_height, 1);

	glPushMatrix();
	glTranslatef(0.f, -leg_height, 0.f);
	glRotatef(right_leg_angle_2, 1.f, 0.f, 0.f);
	drawCube(arm_length, arm_width, leg_height, 1);
	glPopMatrix();

	glPopMatrix();
}

void People::drawCube(float length, float width, float height,int tex_input) {
	float cube_width = width;
	float cube_height = height;
	float cube_length = length;
	int tex = tex_input;
	
	if (toTexture) glEnable(GL_TEXTURE_2D);
	if (toTexture) glBindTexture(GL_TEXTURE_2D, texids[tex]);
	//near
	glNormal3f(0.f, 0.f, 1.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(length, 0.f, width);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, 0.f, width);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, -height, width);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(length, -height, width);
	glEnd();

	//left
	glNormal3f(-1.f, 0.f, 0.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(0.f, 0.f, width);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, 0.f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, -height, 0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(0.f, -height, width);
	glEnd();

	//right
	glNormal3f(1.f, 0.f, 0.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(length, 0.f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(length,0.f, width);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(length, -height, width);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(length, -height, 0.f);
	glEnd();

	//back
	glNormal3f(0.f, 0.f, -1.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(length, 0.f, 0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(length, -height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, -height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(0.f, 0.f, 0.f);
	glEnd();

	//top
	glNormal3f(0.f, 1.f, 0.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(length, 0.f, 0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(0, 0.f, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, 0.f, width);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(length, 0.f, width);
	glEnd();

	//buttom
	glNormal3f(0.f, -1.f, 0.f);
	glBegin(GL_QUADS);
	if (toTexture) glTexCoord2f(1.f, 1.f);
	glVertex3f(length, -height, 0.f);
	if (toTexture) glTexCoord2f(1.f, 0.f);
	glVertex3f(0, -height, 0.f);
	if (toTexture) glTexCoord2f(0.f, 0.f);
	glVertex3f(0.f, -height, width);
	if (toTexture) glTexCoord2f(0.f, 1.f);
	glVertex3f(length, -height, width);
	glEnd();

}

void People::HandleKey(unsigned char key, int state, int x, int y) {

	

	if (!state) return;

	switch (key)
	{
	case 'e':
		light = !light;
		break;
	case 'v':
		if (left) {
			cout << "print";

			pos[0] = pos[0] - move;
		}
		else if (right) {
			pos[0] = pos[0] + move;
		}
		else if (forward) {
			pos[2] = pos[2] + move;
		}
		else if (back) {
			pos[2] = pos[2] - move;
		}
		move = 0;
		_runtime = 0;
		forward = true;
		left = false;
		right = false;
		back = false;

		orientation(0, 0, 0);
		//move = 0;

		break;
	case 'c':
		if (left) {
			cout << "print";

			pos[0] = pos[0] - move;
		}
		else if (right) {
			pos[0] = pos[0] + move;
		}
		else if (forward) {
			pos[2] = pos[2] + move;
		}
		else if (back) {
			pos[2] = pos[2] - move;
		}
		move = 0;
		_runtime = 0;
		forward = false;
		left = true;
		right = false;
		back = false;
		orientation(0,-90,0);
		//move = 0;
		break;
	case 'b':
		if (left) {
			cout << "print";

			pos[0] = pos[0] - move;
		}
		else if (right) {
			pos[0] = pos[0] + move;
		}
		else if (forward) {
			pos[2] = pos[2] + move;
		}
		else if (back) {
			pos[2] = pos[2] - move;
		}
		_runtime = 0;
		forward = false;
		left = false;
		right = true;
		back = false;
		orientation(0, 90, 0);
		move = 0;
		break;
	case 'f':
		if (left) {
			cout << "print";

			pos[0] = pos[0] - move;
		}
		else if (right) {
			pos[0] = pos[0] + move;
		}
		else if (forward) {
			pos[2] = pos[2] + move;
		}
		else if (back) {
			pos[2] = pos[2] - move;
		}
		_runtime = 0;
		forward = false;
		left = false;
		right = false;
		back = true;
		orientation(0, 180, 0);
		move = 0;
		break;

	case 'p':
		if (left) {
			cout << "print";

			pos[0] = pos[0] - move;
		}
		else if (right) {
			pos[0] = pos[0] + move;
		}
		else if (forward) {
			pos[2] = pos[2] + move;
		}
		else if (back) {
			pos[2] = pos[2] - move;
		}
		_runtime = 0;
		forward = false;
		left = false;
		right = false;
		back = false;

		break;

	}

}

void People::Update(const double& deltaTime) {
	if (forward || back || left || right) {
		/*if (false) {*/
		_runtime = fmod(_runtime + deltaTime, animationTime);          // update time in animation cycle
		float stage = 29.f*_runtime / animationTime;         // calculate stage (out of 29)

		old_move = move;
		if (stage < 1) {
			counter = 0;
			left_arm_angle_1 = 3.f;
			right_arm_angle_1 = -3.f;
			left_leg_angle_1 = -6.f;
			left_leg_angle_2 = 2.f;
			//right_leg_angle_1 = 6.f;
			right_leg_angle_1 = 1.f;
			right_leg_angle_2 = 1.f;
			move = 2.f;
			


		}

		else if (stage < 2) {
			left_arm_angle_1 = 6.f;
			right_arm_angle_1 = -6.f;
			left_leg_angle_1 = -6.f;
			left_leg_angle_2 = 7.f;
			right_leg_angle_1 = 3.f;
			right_leg_angle_2 = 3.f;
			move = 4.f;
		}

		else if (stage < 3) {
			left_arm_angle_1 = 9.f;
			right_arm_angle_1 = -9.f;
			left_leg_angle_1 = -12.f;
			left_leg_angle_2 = 12.f;
			right_leg_angle_1 = 5.f;
			right_leg_angle_2 = 5.f;
			move = 6.f;
		}
		else if (stage < 4) {
			left_arm_angle_1 = 12.f;
			right_arm_angle_1 = -12.f;
			left_leg_angle_1 = -24.f;
			left_leg_angle_2 = 17.f;
			right_leg_angle_1 = 7.f;
			right_leg_angle_2 = 7.f;
			move = 8.f;
		}
		else if (stage < 5) {
			left_arm_angle_1 = 15.f;
			right_arm_angle_1 = -15.f;
			left_leg_angle_1 = -30.f;
			left_leg_angle_2 = 22.f;
			right_leg_angle_1 = 9.f;
			right_leg_angle_2 = 9.f;
			move = 10.f;
		}
		else if (stage < 6) {
			left_arm_angle_1 = 18.f;
			right_arm_angle_1 = -18.f;
			left_leg_angle_1 = -36.f;
			left_leg_angle_2 = 27.f;
			right_leg_angle_1 = 11.f;
			right_leg_angle_2 = 11.f;
			move = 12.f;
		}
		else if (stage < 7) {
			left_arm_angle_1 = 21.f;
			right_arm_angle_1 = -21.f;
			left_leg_angle_1 = -42.f;
			left_leg_angle_2 = 32.f;
			right_leg_angle_1 = 13.f;
			right_leg_angle_2 = 13.f;
			move = 14.f;
		}
		//drop left feet


		else if (stage < 8) {
			left_arm_angle_1 = 18.f;
			right_arm_angle_1 = -18.f;
			left_leg_angle_1 = -36.f;
			left_leg_angle_2 = 27.f;
			right_leg_angle_1 = 11.f;
			right_leg_angle_2 = 6.f;

			move = 16.f;
		}
		else if (stage < 9) {
			left_arm_angle_1 = 15.f;
			right_arm_angle_1 = -15.f;
			left_leg_angle_1 = -30.f;
			left_leg_angle_2 = 22.f;
			right_leg_angle_1 = 9.f;
			right_leg_angle_2 = 9.f;
			move = 18.f;
		}
		else if (stage < 10) {
			left_arm_angle_1 = 12.f;
			right_arm_angle_1 = -12.f;
			left_leg_angle_1 = -24.f;
			left_leg_angle_2 = 17.f;
			right_leg_angle_1 = 7.f;
			right_leg_angle_2 = 7.f;
			move = 20.f;
		}
		else if (stage < 11) {
			left_arm_angle_1 = 9.f;
			right_arm_angle_1 = -9.f;
			left_leg_angle_1 = -18.f;
			left_leg_angle_2 = 12.f;
			right_leg_angle_1 = 5.f;
			right_leg_angle_2 = 5.f;
			move = 22.f;
		}
		else if (stage < 12) {
			left_arm_angle_1 = 6.f;
			right_arm_angle_1 = -6.f;
			left_leg_angle_1 = -12.f;
			left_leg_angle_2 = 7.f;
			right_leg_angle_1 = 3.f;
			right_leg_angle_2 = 3.f;
			move = 24.f;
		}
		else if (stage < 13) {
			left_arm_angle_1 = 3.f;
			right_arm_angle_1 = -3.f;
			left_leg_angle_1 = -6.f;
			left_leg_angle_2 = 2.f;
			right_leg_angle_1 = 1.f;
			right_leg_angle_2 = 1.f;
			move = 26.f;
		}


		else if (stage < 14) {
			left_arm_angle_1 = 0.f;
			right_arm_angle_1 = 0.f;
			left_leg_angle_1 = 0.f;
			left_leg_angle_2 = 0.f;
			right_leg_angle_1 = 0.f;
			right_leg_angle_2 = 0.f;
			move = 28.f;
		}
		//raise right leg
		else if (stage < 15) {
			right_arm_angle_1 = 3.f;
			left_arm_angle_1 = -3.f;
			right_leg_angle_1 = -6.f;
			right_leg_angle_2 = 2.f;
			//right_leg_angle_1 = 6.f;
			left_leg_angle_1 = 1.f;
			left_leg_angle_2 = 1.f;
			move = 30.f;


		}

		else if (stage < 16) {
			right_arm_angle_1 = 6.f;
			left_arm_angle_1 = -6.f;
			right_leg_angle_1 = -6.f;
			right_leg_angle_2 = 7.f;
			left_leg_angle_1 = 3.f;
			left_leg_angle_2 = 3.f;
			move = 32.f;
		}

		else if (stage < 17) {
			right_arm_angle_1 = 9.f;
			left_arm_angle_1 = -9.f;
			right_leg_angle_1 = -12.f;
			right_leg_angle_2 = 12.f;
			left_leg_angle_1 = 5.f;
			left_leg_angle_2 = 5.f;
			move = 34.f;
		}
		else if (stage < 18) {
			right_arm_angle_1 = 12.f;
			left_arm_angle_1 = -12.f;
			right_leg_angle_1 = -24.f;
			right_leg_angle_2 = 17.f;
			left_leg_angle_1 = 7.f;
			left_leg_angle_2 = 7.f;
			move = 36.f;
		}
		else if (stage < 19) {
			right_arm_angle_1 = 15.f;
			left_arm_angle_1 = -15.f;
			right_leg_angle_1 = -30.f;
			right_leg_angle_2 = 22.f;
			left_leg_angle_1 = 9.f;
			left_leg_angle_2 = 9.f;
			move = 38.f;
		}
		else if (stage < 20) {
			right_arm_angle_1 = 18.f;
			left_arm_angle_1 = -18.f;
			right_leg_angle_1 = -36.f;
			right_leg_angle_2 = 27.f;
			left_leg_angle_1 = 11.f;
			left_leg_angle_2 = 11.f;
			move = 40.f;
		}
		else if (stage < 21) {
			right_arm_angle_1 = 21.f;
			left_arm_angle_1 = -21.f;
			right_leg_angle_1 = -42.f;
			right_leg_angle_2 = 32.f;
			left_leg_angle_1 = 13.f;
			left_leg_angle_2 = 13.f;
			move = 42.f;
		}
		//drop left feet


		else if (stage < 22) {
			right_arm_angle_1 = 18.f;
			left_arm_angle_1 = -18.f;
			right_leg_angle_1 = -36.f;
			right_leg_angle_2 = 27.f;
			left_leg_angle_1 = 11.f;
			left_leg_angle_2 = 6.f;

			move = 44.f;
		}
		else if (stage < 23) {
			right_arm_angle_1 = 15.f;
			left_arm_angle_1 = -15.f;
			right_leg_angle_1 = -30.f;
			right_leg_angle_2 = 22.f;
			left_leg_angle_1 = 9.f;
			left_leg_angle_2 = 9.f;
			move = 46.f;
		}
		else if (stage < 24) {
			right_arm_angle_1 = 12.f;
			left_arm_angle_1 = -12.f;
			right_leg_angle_1 = -24.f;
			right_leg_angle_2 = 17.f;
			left_leg_angle_1 = 7.f;
			left_leg_angle_2 = 7.f;
			move = 48.f;
		}
		else if (stage < 25) {
			right_arm_angle_1 = 9.f;
			left_arm_angle_1 = -9.f;
			right_leg_angle_1 = -18.f;
			right_leg_angle_2 = 12.f;
			left_leg_angle_1 = 5.f;
			left_leg_angle_2 = 5.f;
			move = 50.f;
		}
		else if (stage < 26) {
			right_arm_angle_1 = 6.f;
			left_arm_angle_1 = -6.f;
			right_leg_angle_1 = -12.f;
			right_leg_angle_2 = 7.f;
			left_leg_angle_1 = 3.f;
			left_leg_angle_2 = 3.f;
			move = 52.f;
		}
		else if (stage < 27) {
			right_arm_angle_1 = 3.f;
			left_arm_angle_1 = -3.f;
			right_leg_angle_1 = -6.f;
			right_leg_angle_2 = 2.f;
			left_leg_angle_1 = 1.f;
			left_leg_angle_2 = 1.f;
			move = 54.f;
		}
		else if (stage < 28) {
			right_arm_angle_1 = 0.f;
			left_arm_angle_1 = 0.f;
			right_leg_angle_1 = 0.f;
			right_leg_angle_2 = 0.f;
			left_leg_angle_1 = 0.f;
			left_leg_angle_2 = 0.f;
			move = 56.f;

		}
		else if (stage < 29) {
		if (counter == 0) {
			move = 0;
		 if (left) {
			 cout << "print";

		 pos[0] = pos[0]-56.f ;
				}
		 else if (right){
		 pos[0] = pos[0] + 56.f;
			}
		else if (forward) {
		 pos[2] = pos[2] + 56.f;
			}
		else if (back) {
		 pos[2] = pos[2] - 56.f;
			}
		}
		counter++;

	}
	
	







	}
}