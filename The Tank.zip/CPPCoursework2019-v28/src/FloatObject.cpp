#include"header.h"
#include "FloatObject.h"
#include"DisplayableObject.h"
#include "CollisionDetection.h"
#include"BaseEngine.h"


extern int score;
extern int life;
FloatObject::FloatObject(BaseEngine* pEngine, std::string strURL)
	:AutoObject(pEngine,strURL,9),speed(speed)
{
}



FloatObject::~FloatObject()
{
}



void FloatObject::virtDoUpdate(int iCurrentTime)
{
	
	if (!isVisible()) {
		m_iCurrentScreenX = -50;
		m_iCurrentScreenY = -50;
		//redrawDisplay();
		setVisible(true);
		move.reverse();
		move.reverse();
		redrawDisplay();
		return;
	}

	//flo = new FloatObject(m_pEngine, 20);
	//appendObjectToArray(flo);
	move.calculate(iCurrentTime);
	m_iCurrentScreenX = move.getX();
	m_iCurrentScreenY = move.getY();
	
	if (move.hasMovementFinished(iCurrentTime))
	{
		setVisible(true);
		move.reverse();
		move.reverse();

	}
	DisplayableObject* pObject;
	pObject = m_pEngine->getDisplayableObject(0);
	if (CollisionDetection::checkRectangles(getDrawingRegionLeft(), getDrawingRegionRight(), getDrawingRegionTop(), getDrawingRegionBottom(), pObject->getDrawingRegionLeft(), pObject->getDrawingRegionRight(), pObject->getDrawingRegionTop(), pObject->getDrawingRegionBottom())) {

		//printf("hhhhhhhhhhhhhhhhhhhhhh");
		score = score + 20;
		life = life + 1;
		setVisible(false);
		pObject->setVisible(false);

	}

	
}




