#include "header.h"
#include "MyTileManager.h"



//MyTileManager::MyTileManager()
//{

//}

MyTileManager::~MyTileManager()
{
}
MyTileManager::MyTileManager()
	: TileManager(5, 10, 15, 15)
{
}
void MyTileManager::virtDrawTileAt(
	BaseEngine* pEngine, 
	DrawingSurface* pSurface,
	int iMapX, int iMapY,
	int iStartPositionScreenX, int iStartPositionScreenY) const
{
	int iMapValue = getMapValue(iMapX, iMapY);
	//unsigned int iColour = (0x100000 * (iMapX & 1)
		//+ 0x001000 * (iMapX & 2)
		//+ 0x000010 * (iMapX & 4)
		//+ 0x010000 * (iMapY & 1)
		//+ 0x000100 * (iMapY & 2)
		//+ 0x000001 * (iMapX & 4)) * (iMapValue % 16);
	unsigned int iColour = 0x006400;
	pSurface->drawRectangle(
		iStartPositionScreenX, // Left
		iStartPositionScreenY, // Top
		iStartPositionScreenX + getTileWidth() - 1, // Right
		iStartPositionScreenY + getTileHeight() - 1, // Bottom
		iColour);
}
