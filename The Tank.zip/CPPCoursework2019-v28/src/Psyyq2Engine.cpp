#include"header.h"
#include "Psyyq2Engine.h"
#include"ControllingObject.h"


int score = 0;
int life = 5;

//Psyyq2Engine::Psyyq2Engine()
		
//{
	
//}

Psyyq2Engine::~Psyyq2Engine()
{
}


void Psyyq2Engine::virtSetupBackgroundBuffer()
{
	//int radius = 100;
	fillBackground(0x98FB98);
	
	//unsigned int start_color = 0x800000;
	//unsigned int start_color = 0xFF4500;
	//for (int iX = 0; iX < getWindowWidth(); iX++) {
		// int temcolor = start_color;
		//for (int iY = 0; iY < this->getWindowHeight(); iY++) {
			//setBackgroundPixel(iX, iY, start_color);
			//start_color = start_color + 1;


		//}
	//}

	
	drawBackgroundRectangle(getWindowWidth()/3,getWindowHeight()/3+100, (getWindowWidth() / 3) +10, getWindowHeight()/3, 0x2F4F4F);
	drawBackgroundRectangle(2 * getWindowWidth() / 3, getWindowHeight() / 3 + 100, (2 * getWindowWidth() / 3) + 10, getWindowHeight() / 3, 0x2F4F4F);
	drawBackgroundRectangle( getWindowWidth() / 2-25, getWindowHeight() / 3 + 200,  getWindowWidth() / 2+25, getWindowHeight() /3 +190, 0x2F4F4F);
	drawBackgroundRectangle(getWindowWidth() / 2 - 65, getWindowHeight() / 3 - 50, getWindowWidth() / 2 + 65, getWindowHeight() / 3 - 150, 0x2F4F4F);
	
	tm.setTopLeftPositionOnScreen(0, 533);
	
	tm.drawAllTiles(this, getBackgroundSurface()); // Draw to background!
}

	//for (int j = 0; j < 24; j++)
	//{
	//	tm.setMapValue(1, j, j);
	//}
	//tm.setTopLeftPositionOnScreen(0,525);
	//tm.drawAllTiles(this, getBackgroundSurface());
	



int Psyyq2Engine::virtInitialiseObjects()
{
	Co = new ControllingObject (this,&tm,"bunny.jpg");
	//ao = new AutoObject(this);
	po = new PinObject(this, "carrot.jpg");
	po1 = new PinObject(this, "carrot.jpg");
	po2 = new PinObject(this, "carrot.jpg");
	//po3= new PinObject(this, "carrot.jpg");
	//po4 = new PinObject(this, "carrot.jpg");
	//po4 = new PinObject(this, ;
	//po4= new PinObject(this, ;
	//po5 = new PinObject(this, "carrot.jpg");
	po6 = new PinObject(this, "carrot.jpg");
	//po7 = new PinObject(this, "carrot.jpg");
	fo = new FloatObject(this,"bunnyC.jpg");
	fo1 = new FloatObject(this,"bunnyC.jpg");
	fo2 = new FloatObject(this,"bunnyC.jpg");
	po->setMove(getModifiedTime()+500, getModifiedTime() + 2000, getModifiedTime(), 450, -58,400, 610);
	po1->setMove(getModifiedTime()+1100, getModifiedTime() + 2700, getModifiedTime(), 100, -58, 100, 610);
	po2->setMove(getModifiedTime()+2000, getModifiedTime() + 4500, getModifiedTime(), 200, -58, 200, 610);
	
	//po3->setMove(getModifiedTime()+4700, getModifiedTime() + 5700, getModifiedTime(), 300, -58, 300, 610);
	//po4->setMove(getModifiedTime()+3400, getModifiedTime() + 4400, getModifiedTime(), 400, -58, 400, 610);
	//po5->setMove(getModifiedTime()+6900, getModifiedTime() + 7900, getModifiedTime(), 500, -58, 500, 610);
	po6->setMove(getModifiedTime()+6600, getModifiedTime() +8900, getModifiedTime(), 600, -58, 600, 610);
	fo->setMove(getModifiedTime()+1000, getModifiedTime() + 3500, getModifiedTime(), 300, -58,300, 533);
	fo1->setMove(getModifiedTime()+3000, getModifiedTime() + 5500, getModifiedTime(), 470, -58, 400, 533);
	fo2->setMove(getModifiedTime()+6000, getModifiedTime() + 8500, getModifiedTime(), 555, -58, 555, 533);

	drawableObjectsChanged();
	destroyOldObjects(true);
	createObjectArray(20);
	
	storeObjectInArray(0, Co);
	storeObjectInArray(1, po);
	storeObjectInArray(2, po1);
	storeObjectInArray(3, po2);
	storeObjectInArray(4, fo1);
	///////storeObjectInArray(5, po4);
	///////////..//reObjectInArray(6, po5);
	storeObjectInArray(5, po6);
	////////storeObjectInArray(8, po7);
	storeObjectInArray(6, fo);
	storeObjectInArray(7, fo2);
	setAllObjectsVisible(true);
	return 0;
}


void Psyyq2Engine::virtMouseDown(int iButton, int iX, int iY)
{
	//if (500<iY<550) {
	//	Co->setPosition(iX, iY);
	//}
	
	Co->setPosition(iX, Co->getDrawingRegionTop());
}


void Psyyq2Engine::virtKeyDown(int iKeyCode)
{
	switch (iKeyCode)
	{
	case SDLK_ESCAPE: // End program when escape is pressed
		setExitWithCode(0);
		break;
	case SDLK_SPACE:
		//setExitWithCode(0);
		sho = new ShootingObject(this);
		sho->setMove(getModifiedTime(), getModifiedTime() + 800, getModifiedTime(), Co->getPosX()+25, Co->getPosY(), Co->getPosX()+25, Co->getPosY() -600);
		appendObjectToArray(sho);
		//sho->setVisible(true);
		//printf("hereeeeeeeeeeeeeeeeeeeeeeeee");
		break;
	}
	
}


//void Psyyq2Engine::Notify(int iCurrentTime)
//{
	// TODO: �ڴ˴�����ʵ�ִ���.
//	fo2 = new FloatObject(this, 20);
//	appendObjectToArray(fo2);
	
//}


void Psyyq2Engine::virtDrawStringsUnderneath()
{
	drawBackgroundString(550,10, "Shooting Bunny", 0x2F4F4F, NULL);

}


void Psyyq2Engine::virtDrawStringsOnTop()
{
	char buf[128];
	sprintf(buf, "Time %6d",getModifiedTime()/1000);
	drawForegroundString(30, 10, buf, 0x2F4F4F, NULL);
	char buff[128];
	sprintf(buff, "Score %6d",score);
	drawForegroundString(30, 30, buff, 0x2F4F4F, NULL);
	char buff1[128];
	sprintf(buff1, "Life %6d", life);
	drawForegroundString(30, 50, buff1, 0x2F4F4F, NULL);

}
