#include"header.h"
#include "PinObject.h"
#include"DisplayableObject.h"
//#include"DisplayableObjectContainer.h"
#include "CollisionDetection.h"
#include"BaseEngine.h"
#include"MovementPosition.h"

extern int life;
extern int score;

PinObject::PinObject(BaseEngine* pEngine, std::string strURL)
	: AutoObject(pEngine,strURL,4)
{
	
}


PinObject::~PinObject()
{
}


//void PinObject::setMove(int iStartTime, int iEndTime, int iCurrentTime,
	//int iStartX, int iStartY, int iEndX, int iEndY)
//{
//	move.setup(iStartX, iStartY, iEndX, iEndY, iStartTime, iEndTime);
	//move.calculate(iCurrentTime);
	//move.calculate(iCurrentTime);
	//m_iCurrentScreenX = move.getX();
	//m_iCurrentScreenY = move.getY();


//}



void PinObject::virtDoUpdate(int iCurrentTime)
{
if (!isVisible()) {


		//printf("HIIIIIIIIIIIIIIIIIIIIIII!!!!!");
		m_iCurrentScreenX = -50;
		m_iCurrentScreenY = -50;
		move.reverse();
		move.reverse();
		setVisible(true);
		//reverse reverse didnot change the current position so change the current position first
		redrawDisplay();
//		
		
			
//			
		return;
	}
		
	//flo = new FloatObject(m_pEngine, 20);
	//appendObjectToArray(flo);
	move.calculate(iCurrentTime);
	m_iCurrentScreenX = move.getX();
	
	m_iCurrentScreenY = move.getY();
	redrawDisplay();
	//printf("gethereeeeeeeeeeeeeeeeeeeeeeeeeeeee %d", move.getX());
	if(move.hasMovementFinished(iCurrentTime))
	{
		//setVisible(true);
		move.reverse();
		move.reverse();
		
		

	}

	DisplayableObject* pObject;
	pObject = m_pEngine->getDisplayableObject(0);
	if (CollisionDetection::checkRectangles(getDrawingRegionLeft(), getDrawingRegionRight(), getDrawingRegionTop(), getDrawingRegionBottom(), pObject->getDrawingRegionLeft(), pObject->getDrawingRegionRight(), pObject->getDrawingRegionTop(), pObject->getDrawingRegionBottom())) {

		//printf("2222222222222222222c");
		score = score -20;
		life = life - 1;
		if (life == 0) {
			m_pEngine->setExitWithCode(0);
		}
		setVisible(false);
		pObject->setVisible(false);

	}
		




	redrawDisplay();

}
