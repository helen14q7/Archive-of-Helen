#pragma once
#include "DisplayableObject.h"
#include"SimpleImage.h"
#include"MovementPosition.h"
using namespace std;
class AutoObject :
	public DisplayableObject
{
protected:
	SimpleImage image;
public:

	//AutoObject(BaseEngine* pEngine);
	AutoObject(BaseEngine* pEngine, std::string strURL,int mul);
	//AutoObject(BaseEngine* pEngine, unsigned int color, std::string strURL,int mul);
	void setMove(int iStartTime, int iEndTime, int iCurrentTime, int iStartX, int iStartY, int iEndX, int iEndY);
	~AutoObject();
	void virtDraw();
protected:
	int mul;
	MovementPosition move;
	
};

