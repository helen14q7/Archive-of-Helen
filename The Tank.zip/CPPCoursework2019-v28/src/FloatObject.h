#pragma once
#include "AutoObject.h"
class FloatObject :
	public AutoObject
{
public:
	FloatObject(BaseEngine* pEngine,std::string strURL);
	~FloatObject();


	void virtDoUpdate(int iCurrentTime);
protected:
	int speed;

};

