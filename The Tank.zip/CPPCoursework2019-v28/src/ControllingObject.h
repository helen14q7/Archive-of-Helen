#pragma once
#include "DisplayableObject.h"
#include"psyyq2TileManager.h"
class psyyq2TileManager;
class ControllingObject :
	public DisplayableObject
{
public:
	ControllingObject(BaseEngine* pEngine, psyyq2TileManager* ptm);
	ControllingObject(BaseEngine* pEngine, psyyq2TileManager* ptm, std::string strURL);
	~ControllingObject();
	
	void virtDraw();
	void virtDoUpdate(int iCurrentTime);
protected:
	psyyq2TileManager* ptm;
	

public:
	int getPosX();
	int getPosY();
private:
	SimpleImage image;
};

