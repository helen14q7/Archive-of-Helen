#pragma once
#include "AutoObject.h"
#include"BaseEngine.h"
#include"MovementPosition.h"
#include"FloatObject.h"
class PinObject :
	public AutoObject
{
public:
	
	PinObject(BaseEngine* pEngine, std::string strURL);
	//void setMove(int iStartTime, int iEndTime, int iCurrentTime,
	//	int iStartX, int iStartY, int iEndX, int iEndY);
	~PinObject();

	
protected:
	//MovementPosition move;
	//FloatObject* flo;
	
public:
	void virtDoUpdate(int iCurrentTime);
};


