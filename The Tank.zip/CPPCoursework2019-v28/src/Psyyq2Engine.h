#pragma once
#include "BaseEngine.h"
#include"ControllingObject.h"
#include"psyyq2TileManager.h"
#include"PinObject.h"
#include"FloatObject.h"
#include"ShootingObject.h"
class BouncingBall;
class Psyyq2Engine :
	public BaseEngine
{
public:
	Psyyq2Engine()
		:Co(NULL),po(NULL)
	{}
	
	~Psyyq2Engine();
	void virtSetupBackgroundBuffer();

	int virtInitialiseObjects();
	void virtMouseDown(int iButton, int iX, int iY);

private:
	ControllingObject* Co;
	psyyq2TileManager tm;
	PinObject *po;
	PinObject *po1;
	PinObject *po2;
	//PinObject *po3;
	//PinObject *po4;
	//PinObject *po5;
	PinObject *po6;
	//PinObject *po7;
	ShootingObject *sho;
	FloatObject *fo;
	FloatObject *fo1;
	FloatObject *fo2;
	
public:
	void virtKeyDown(int iKeyCode);
	//void Notify(int iCurrentTime);
	void virtDrawStringsUnderneath();
	void virtDrawStringsOnTop();
};

