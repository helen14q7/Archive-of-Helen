To build on Linux:
- copy the makefile from this directory into the same directory as the source files (../src if you haven't moved anything).
- in a terminal move to the source directory (src) and run 'make'


If it complains about missing libraries, then the libraries libsdl2-dev, libsdl2-image-dev and libsdl2-ttf-dev need to be installed. 
Install these dependencies according to your Linux installation. 
For example on Ubuntu(and derivatives) you use "sudo apt install libsdl2-dev libsdl2-image-dev libsdl2-ttf-dev"




